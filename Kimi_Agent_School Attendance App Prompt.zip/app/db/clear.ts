import { getDb } from "../api/queries/connection";
import { sql } from "drizzle-orm";

async function clear() {
  const db = getDb();
  await db.execute(sql`SET FOREIGN_KEY_CHECKS = 0`);
  await db.execute(sql`TRUNCATE TABLE attendance_records`);
  await db.execute(sql`TRUNCATE TABLE grades`);
  await db.execute(sql`TRUNCATE TABLE assessments`);
  await db.execute(sql`TRUNCATE TABLE teacher_classes`);
  await db.execute(sql`TRUNCATE TABLE announcements`);
  await db.execute(sql`TRUNCATE TABLE students`);
  await db.execute(sql`TRUNCATE TABLE teachers`);
  await db.execute(sql`TRUNCATE TABLE users`);
  await db.execute(sql`TRUNCATE TABLE subjects`);
  await db.execute(sql`TRUNCATE TABLE classes`);
  await db.execute(sql`TRUNCATE TABLE schools`);
  await db.execute(sql`SET FOREIGN_KEY_CHECKS = 1`);
  console.log("Database cleared");
  process.exit(0);
}

clear().catch((err) => {
  console.error(err);
  process.exit(1);
});
