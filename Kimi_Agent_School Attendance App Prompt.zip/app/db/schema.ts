import {
  mysqlTable,
  mysqlEnum,
  serial,
  bigint,
  varchar,
  text,
  timestamp,
  int,
  date,
  decimal,
  index,
} from "drizzle-orm/mysql-core";

// ─── Schools ──────────────────────────────────────────────────
export const schools = mysqlTable("schools", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 255 }),
  principalName: varchar("principal_name", { length: 255 }),
  establishedYear: int("established_year"),
  status: mysqlEnum("status", ["active", "inactive"]).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});

export type School = typeof schools.$inferSelect;
export type InsertSchool = typeof schools.$inferInsert;

// ─── Classes ──────────────────────────────────────────────────
export const classes = mysqlTable("classes", {
  id: serial("id").primaryKey(),
  schoolId: bigint("school_id", { mode: "number", unsigned: true }).references(() => schools.id),
  name: varchar("name", { length: 255 }).notNull(),
  gradeLevel: int("grade_level").notNull(),
  section: varchar("section", { length: 10 }),
  academicYear: varchar("academic_year", { length: 20 }).notNull(),
  roomNumber: varchar("room_number", { length: 50 }),
  status: mysqlEnum("status", ["active", "inactive"]).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});

export type Class = typeof classes.$inferSelect;
export type InsertClass = typeof classes.$inferInsert;

// ─── Subjects ─────────────────────────────────────────────────
export const subjects = mysqlTable("subjects", {
  id: serial("id").primaryKey(),
  schoolId: bigint("school_id", { mode: "number", unsigned: true }).references(() => schools.id),
  name: varchar("name", { length: 255 }).notNull(),
  code: varchar("code", { length: 50 }).notNull(),
  description: text("description"),
  credits: int("credits").default(1),
  status: mysqlEnum("status", ["active", "inactive"]).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

// ─── Users ────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin", "teacher", "student", "parent"]).default("user").notNull(),
  schoolId: bigint("school_id", { mode: "number", unsigned: true }).references(() => schools.id),
  status: mysqlEnum("status", ["active", "inactive"]).default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Teachers ─────────────────────────────────────────────────
export const teachers = mysqlTable("teachers", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).references(() => users.id),
  employeeId: varchar("employee_id", { length: 100 }).notNull().unique(),
  qualification: varchar("qualification", { length: 255 }),
  specialization: varchar("specialization", { length: 255 }),
  joinDate: date("join_date"),
  phone: varchar("phone", { length: 50 }),
  status: mysqlEnum("status", ["active", "inactive"]).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = typeof teachers.$inferInsert;

// ─── Teacher-Class Assignments ────────────────────────────────
export const teacherClasses = mysqlTable("teacher_classes", {
  id: serial("id").primaryKey(),
  teacherId: bigint("teacher_id", { mode: "number", unsigned: true }).references(() => teachers.id),
  classId: bigint("class_id", { mode: "number", unsigned: true }).references(() => classes.id),
  subjectId: bigint("subject_id", { mode: "number", unsigned: true }).references(() => subjects.id),
  academicYear: varchar("academic_year", { length: 20 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export type TeacherClass = typeof teacherClasses.$inferSelect;

// ─── Students ─────────────────────────────────────────────────
export const students = mysqlTable("students", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).references(() => users.id),
  studentId: varchar("student_id", { length: 100 }).notNull().unique(),
  classId: bigint("class_id", { mode: "number", unsigned: true }).references(() => classes.id),
  rollNumber: int("roll_number"),
  dateOfBirth: date("date_of_birth"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  parentName: varchar("parent_name", { length: 255 }),
  parentPhone: varchar("parent_phone", { length: 50 }),
  parentEmail: varchar("parent_email", { length: 255 }),
  address: text("address"),
  emergencyContact: varchar("emergency_contact", { length: 50 }),
  bloodGroup: varchar("blood_group", { length: 10 }),
  admissionDate: date("admission_date"),
  status: mysqlEnum("status", ["active", "inactive", "graduated", "transferred"]).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
}, (table) => [
  index("student_class_idx").on(table.classId),
]);

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

// ─── Attendance Records ──────────────────────────────────────
export const attendanceRecords = mysqlTable("attendance_records", {
  id: serial("id").primaryKey(),
  studentId: bigint("student_id", { mode: "number", unsigned: true }).references(() => students.id),
  classId: bigint("class_id", { mode: "number", unsigned: true }).references(() => classes.id),
  teacherId: bigint("teacher_id", { mode: "number", unsigned: true }).references(() => teachers.id),
  date: date("date").notNull(),
  status: mysqlEnum("status", ["present", "absent", "late", "excused"]).notNull(),
  notes: text("notes"),
  markedAt: timestamp("marked_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("attendance_date_idx").on(table.date),
  index("attendance_student_idx").on(table.studentId),
  index("attendance_class_idx").on(table.classId),
]);

export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type InsertAttendanceRecord = typeof attendanceRecords.$inferInsert;

// ─── Assessments ──────────────────────────────────────────────
export const assessments = mysqlTable("assessments", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  subjectId: bigint("subject_id", { mode: "number", unsigned: true }).references(() => subjects.id),
  classId: bigint("class_id", { mode: "number", unsigned: true }).references(() => classes.id),
  teacherId: bigint("teacher_id", { mode: "number", unsigned: true }).references(() => teachers.id),
  type: mysqlEnum("type", ["quiz", "assignment", "midterm", "final", "project"]).notNull(),
  totalMarks: int("total_marks").notNull(),
  weight: decimal("weight", { precision: 4, scale: 2 }).default("1.00"),
  dueDate: date("due_date"),
  academicYear: varchar("academic_year", { length: 20 }).notNull(),
  semester: mysqlEnum("semester", ["fall", "spring", "summer"]).notNull(),
  status: mysqlEnum("status", ["active", "completed", "cancelled"]).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Assessment = typeof assessments.$inferSelect;
export type InsertAssessment = typeof assessments.$inferInsert;

// ─── Grades ───────────────────────────────────────────────────
export const grades = mysqlTable("grades", {
  id: serial("id").primaryKey(),
  studentId: bigint("student_id", { mode: "number", unsigned: true }).references(() => students.id),
  assessmentId: bigint("assessment_id", { mode: "number", unsigned: true }).references(() => assessments.id),
  marksObtained: int("marks_obtained").notNull(),
  percentage: decimal("percentage", { precision: 5, scale: 2 }),
  grade: varchar("grade", { length: 5 }),
  gpaPoints: decimal("gpa_points", { precision: 3, scale: 2 }),
  teacherComments: text("teacher_comments"),
  gradedAt: timestamp("graded_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Grade = typeof grades.$inferSelect;
export type InsertGrade = typeof grades.$inferInsert;

// ─── Announcements ────────────────────────────────────────────
export const announcements = mysqlTable("announcements", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  schoolId: bigint("school_id", { mode: "number", unsigned: true }).references(() => schools.id),
  authorId: bigint("author_id", { mode: "number", unsigned: true }).references(() => users.id),
  targetRole: mysqlEnum("target_role", ["all", "admin", "teacher", "student", "parent"]).default("all"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Announcement = typeof announcements.$inferSelect;
export type InsertAnnouncement = typeof announcements.$inferInsert;
