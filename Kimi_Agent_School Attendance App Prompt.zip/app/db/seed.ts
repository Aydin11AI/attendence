import { getDb } from "../api/queries/connection";
import {
  schools, classes, subjects, users, teachers, teacherClasses,
  students, attendanceRecords, assessments, grades, announcements
} from "./schema";
import { eq } from "drizzle-orm";

const db = getDb();

const firstNames = ["James", "Maria", "Robert", "Jennifer", "Michael", "Linda", "William", "Patricia", "David", "Elizabeth", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah", "Charles", "Karen", "Daniel", "Nancy", "Matthew", "Lisa", "Anthony", "Betty", "Mark", "Helen", "Donald", "Sandra", "Steven", "Donna", "Paul", "Carol", "Andrew", "Ruth", "Joshua", "Sharon", "Kenneth", "Michelle", "Kevin", "Emily", "Brian", "Amanda", "George", "Melissa", "Timothy", "Deborah", "Ronald", "Stephanie", "Edward", "Rebecca"];
const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores"];

function rand<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)]; }
function randInt(min: number, max: number) { return Math.floor(Math.random() * (max - min + 1)) + min; }

async function seed() {
  console.log("Seeding database...");

  // ─── 1. School ───────────────────────────────────────────
  const [schoolResult] = await db.insert(schools).values({
    name: "Nexus Academy",
    address: "123 Education Lane, Knowledge City, KC 10001",
    phone: "+1 (555) 123-4567",
    email: "info@nexusacademy.edu",
    principalName: "Dr. Eleanor Vance",
    establishedYear: 1995,
    status: "active",
  });
  const schoolId = Number(schoolResult.insertId);
  console.log("Created school:", schoolId);

  // ─── 2. Classes ──────────────────────────────────────────
  const classValues: any[] = [];
  for (let grade = 1; grade <= 12; grade++) {
    for (const section of ["A", "B"]) {
      classValues.push({
        schoolId, name: `Grade ${grade}-${section}`, gradeLevel: grade,
        section, academicYear: "2025-2026",
        roomNumber: `${grade}${section === "A" ? "01" : "02"}`, status: "active" as const,
      });
    }
  }
  await db.insert(classes).values(classValues);
  const allClasses = await db.select({ id: classes.id }).from(classes).where(eq(classes.schoolId, schoolId));
  const classIds = allClasses.map((c) => c.id);
  console.log("Created", classIds.length, "classes");

  // ─── 3. Subjects ─────────────────────────────────────────
  const subjectList = [
    { name: "Mathematics", code: "MATH", credits: 4 },
    { name: "Science", code: "SCI", credits: 4 },
    { name: "English Language", code: "ENG", credits: 4 },
    { name: "History", code: "HIST", credits: 3 },
    { name: "Geography", code: "GEO", credits: 3 },
    { name: "Physics", code: "PHY", credits: 4 },
    { name: "Chemistry", code: "CHEM", credits: 4 },
    { name: "Biology", code: "BIO", credits: 4 },
    { name: "Computer Science", code: "CS", credits: 3 },
    { name: "Physical Education", code: "PE", credits: 2 },
    { name: "Art", code: "ART", credits: 2 },
    { name: "Music", code: "MUS", credits: 2 },
    { name: "Foreign Language", code: "FL", credits: 3 },
    { name: "Economics", code: "ECON", credits: 3 },
    { name: "Literature", code: "LIT", credits: 3 },
    { name: "Social Studies", code: "SS", credits: 3 },
    { name: "Algebra", code: "ALG", credits: 4 },
    { name: "Geometry", code: "GEO-M", credits: 4 },
    { name: "Calculus", code: "CALC", credits: 4 },
    { name: "Environmental Science", code: "ENV", credits: 3 },
  ];
  await db.insert(subjects).values(subjectList.map((s) => ({ ...s, schoolId, description: `${s.name} curriculum`, status: "active" as const })));
  const allSubjects = await db.select({ id: subjects.id }).from(subjects).where(eq(subjects.schoolId, schoolId));
  const subjectIds = allSubjects.map((s) => s.id);
  console.log("Created", subjectIds.length, "subjects");

  // ─── 4. Admin ────────────────────────────────────────────
  await db.insert(users).values({
    unionId: `admin_${Date.now()}`, name: "Administrator",
    email: "admin@nexusacademy.edu", role: "admin", schoolId, status: "active",
  });

  // ─── 5. Teachers ─────────────────────────────────────────
  const specs = ["Mathematics", "Science", "English", "History", "Physics", "Chemistry", "Biology", "Computer Science", "Arts", "Physical Education", "Music", "Foreign Languages"];
  const quals = ["M.Ed.", "Ph.D.", "B.Ed.", "M.A.", "M.Sc.", "Ed.D."];
  const teacherData: { id: number; userId: number }[] = [];

  for (let i = 0; i < 25; i++) {
    const [ur] = await db.insert(users).values({
      unionId: `t_${i}_${Date.now()}`, name: `${rand(firstNames)} ${rand(lastNames)}`,
      email: `t${i}@nexus.edu`, role: "teacher", schoolId, status: "active",
    });
    const [tr] = await db.insert(teachers).values({
      userId: Number(ur.insertId), employeeId: `EMP${2025000 + i}`,
      qualification: rand(quals), specialization: rand(specs),
      joinDate: new Date(2020 + randInt(0, 5), randInt(0, 11), randInt(1, 28)),
      phone: `+1 (555) ${randInt(100, 999)}-${randInt(1000, 9999)}`, status: "active",
    });
    teacherData.push({ id: Number(tr.insertId), userId: Number(ur.insertId) });
  }
  console.log("Created 25 teachers");

  // Teacher assignments
  const tcBatch = teacherData.map((t, i) => ({
    teacherId: t.id, classId: classIds[i % classIds.length],
    subjectId: subjectIds[i % subjectIds.length], academicYear: "2025-2026",
  }));
  await db.insert(teacherClasses).values(tcBatch);
  console.log("Created teacher assignments");

  // ─── 6. Students (200 for speed) ─────────────────────────
  const genders: ("male" | "female" | "other")[] = ["male", "female", "other"];
  const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
  const studentIds: number[] = [];

  for (let i = 0; i < 200; i++) {
    const classId = classIds[i % classIds.length];
    const gradeLevel = Math.floor(i / 2) + 1;
    const [ur] = await db.insert(users).values({
      unionId: `s_${i}_${Date.now()}`, name: `${rand(firstNames)} ${rand(lastNames)}`,
      email: `s${20250000 + i}@nexus.edu`, role: "student", schoolId, status: "active",
    });
    const [sr] = await db.insert(students).values({
      userId: Number(ur.insertId), studentId: `STU${20250000 + i}`,
      classId, rollNumber: i + 1,
      dateOfBirth: new Date(2010 - gradeLevel + randInt(0, 1), randInt(0, 11), randInt(1, 28)),
      gender: rand(genders), parentName: `${rand(firstNames)} ${rand(lastNames)}`,
      parentPhone: `+1 (555) ${randInt(100, 999)}-${randInt(1000, 9999)}`,
      parentEmail: `p${i}@email.com`, bloodGroup: rand(bloodGroups),
      admissionDate: new Date(2023 + randInt(0, 2), randInt(0, 11), randInt(1, 28)),
      status: "active",
    });
    studentIds.push(Number(sr.insertId));
  }
  console.log("Created 200 students");

  // ─── 7. Attendance (past 14 days, batch insert) ──────────
  const statuses = ["present", "absent", "late", "excused"] as const;
  const weights = [0.85, 0.07, 0.05, 0.03];
  const attendanceBatch: any[] = [];

  for (let day = 0; day < 14; day++) {
    const date = new Date();
    date.setDate(date.getDate() - day);
    date.setHours(0, 0, 0, 0);

    for (let si = 0; si < 100; si++) {
      const sid = studentIds[si];
      let roll = Math.random(), statusIdx = 0;
      for (let w = 0; w < weights.length; w++) { roll -= weights[w]; if (roll <= 0) { statusIdx = w; break; } }
      attendanceBatch.push({
        studentId: sid, classId: classIds[sid % classIds.length],
        teacherId: teacherData[sid % teacherData.length].id,
        date, status: statuses[statusIdx],
        notes: statusIdx > 0 ? `Marked ${statuses[statusIdx]}` : null,
      });
    }
  }
  // Insert in chunks of 200
  for (let i = 0; i < attendanceBatch.length; i += 200) {
    await db.insert(attendanceRecords).values(attendanceBatch.slice(i, i + 200));
  }
  console.log("Created", attendanceBatch.length, "attendance records");

  // ─── 8. Assessments ──────────────────────────────────────
  const aTypes = ["quiz", "assignment", "midterm", "final", "project"] as const;
  const sems = ["fall", "spring"] as const;
  const assessmentIds: number[] = [];

  for (let i = 0; i < 30; i++) {
    const [ar] = await db.insert(assessments).values({
      name: `${aTypes[i % 5].charAt(0).toUpperCase() + aTypes[i % 5].slice(1)} ${Math.floor(i / 5) + 1}`,
      subjectId: subjectIds[i % subjectIds.length],
      classId: classIds[i % classIds.length],
      teacherId: teacherData[i % teacherData.length].id,
      type: aTypes[i % 5], totalMarks: i % 5 === 0 ? 20 : i % 5 === 1 ? 50 : 100,
      weight: ["1.00", "1.50", "2.00"][i % 3],
      dueDate: new Date(2026, randInt(0, 5), randInt(1, 28)),
      academicYear: "2025-2026", semester: sems[i % 2], status: "active",
    });
    assessmentIds.push(Number(ar.insertId));
  }
  console.log("Created 30 assessments");

  // ─── 9. Grades (batch) ───────────────────────────────────
  const gpaMap: Record<string, string> = { A: "4.00", "B+": "3.30", B: "3.00", "C+": "2.30", C: "2.00", D: "1.00", F: "0.00" };
  const gradeBatch: any[] = [];

  for (const aid of assessmentIds) {
    const totalMarks = aid % 5 === 0 ? 20 : aid % 5 === 1 ? 50 : 100;
    for (let si = 0; si < 30; si++) {
      const sid = studentIds[si];
      const marks = Math.max(0, Math.min(totalMarks, Math.floor(totalMarks * (0.4 + Math.random() * 0.55))));
      const pct = Math.round((marks / totalMarks) * 100 * 100) / 100;
      let gl = "F";
      if (pct >= 93) gl = "A"; else if (pct >= 83) gl = "B"; else if (pct >= 73) gl = "C"; else if (pct >= 63) gl = "D";
      gradeBatch.push({
        studentId: sid, assessmentId: aid, marksObtained: marks,
        percentage: pct.toString(), grade: gl,
        gpaPoints: (gpaMap[gl] ?? "0.00"),
        teacherComments: pct >= 90 ? "Excellent!" : pct >= 70 ? "Good" : "Keep trying",
      });
    }
  }
  for (let i = 0; i < gradeBatch.length; i += 200) {
    await db.insert(grades).values(gradeBatch.slice(i, i + 200));
  }
  console.log("Created", gradeBatch.length, "grades");

  // ─── 10. Announcements ───────────────────────────────────
  const adminUser = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin")).limit(1);
  const adminId = adminUser[0]?.id ?? 1;

  await db.insert(announcements).values([
    { title: "Welcome to Spring Semester 2026", content: "Classes begin January 6th. Check your schedules!", schoolId, authorId: adminId, targetRole: "all", priority: "high", expiresAt: new Date(2026, 6, 1) },
    { title: "Parent-Teacher Conferences", content: "Feb 15-16, 2026. Sign up via parent portal.", schoolId, authorId: adminId, targetRole: "parent", priority: "medium", expiresAt: new Date(2026, 2, 20) },
    { title: "Midterm Exams", content: "March 10-14, 2026. Study guides coming soon.", schoolId, authorId: adminId, targetRole: "student", priority: "urgent", expiresAt: new Date(2026, 3, 15) },
    { title: "Extended Library Hours", content: "Open until 7PM weekdays, 2PM Saturdays.", schoolId, authorId: adminId, targetRole: "all", priority: "low", expiresAt: new Date(2026, 8, 1) },
    { title: "Sports Day Registration", content: "April 25, 2026. Register with your PE teacher.", schoolId, authorId: adminId, targetRole: "student", priority: "medium", expiresAt: new Date(2026, 4, 1) },
  ]);
  console.log("Created 5 announcements");

  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch((err) => { console.error(err); process.exit(1); });
