import { relations } from "drizzle-orm";
import {
  users,
  schools,
  classes,
  subjects,
  teachers,
  teacherClasses,
  students,
  attendanceRecords,
  assessments,
  grades,
  announcements,
} from "./schema";

export const schoolsRelations = relations(schools, ({ many }) => ({
  classes: many(classes),
  subjects: many(subjects),
  users: many(users),
  announcements: many(announcements),
}));

export const classesRelations = relations(classes, ({ one, many }) => ({
  school: one(schools, { fields: [classes.schoolId], references: [schools.id] }),
  students: many(students),
  teacherClasses: many(teacherClasses),
  assessments: many(assessments),
  attendanceRecords: many(attendanceRecords),
}));

export const subjectsRelations = relations(subjects, ({ one, many }) => ({
  school: one(schools, { fields: [subjects.schoolId], references: [schools.id] }),
  teacherClasses: many(teacherClasses),
  assessments: many(assessments),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  school: one(schools, { fields: [users.schoolId], references: [schools.id] }),
  teacher: one(teachers, { fields: [users.id], references: [teachers.userId] }),
  student: one(students, { fields: [users.id], references: [students.userId] }),
  authoredAnnouncements: many(announcements),
}));

export const teachersRelations = relations(teachers, ({ one, many }) => ({
  user: one(users, { fields: [teachers.userId], references: [users.id] }),
  teacherClasses: many(teacherClasses),
  assessments: many(assessments),
  attendanceRecords: many(attendanceRecords),
}));

export const teacherClassesRelations = relations(teacherClasses, ({ one }) => ({
  teacher: one(teachers, { fields: [teacherClasses.teacherId], references: [teachers.id] }),
  class: one(classes, { fields: [teacherClasses.classId], references: [classes.id] }),
  subject: one(subjects, { fields: [teacherClasses.subjectId], references: [subjects.id] }),
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  user: one(users, { fields: [students.userId], references: [users.id] }),
  class: one(classes, { fields: [students.classId], references: [classes.id] }),
  attendanceRecords: many(attendanceRecords),
  grades: many(grades),
}));

export const attendanceRecordsRelations = relations(attendanceRecords, ({ one }) => ({
  student: one(students, { fields: [attendanceRecords.studentId], references: [students.id] }),
  class: one(classes, { fields: [attendanceRecords.classId], references: [classes.id] }),
  teacher: one(teachers, { fields: [attendanceRecords.teacherId], references: [teachers.id] }),
}));

export const assessmentsRelations = relations(assessments, ({ one, many }) => ({
  subject: one(subjects, { fields: [assessments.subjectId], references: [subjects.id] }),
  class: one(classes, { fields: [assessments.classId], references: [classes.id] }),
  teacher: one(teachers, { fields: [assessments.teacherId], references: [teachers.id] }),
  grades: many(grades),
}));

export const gradesRelations = relations(grades, ({ one }) => ({
  student: one(students, { fields: [grades.studentId], references: [students.id] }),
  assessment: one(assessments, { fields: [grades.assessmentId], references: [assessments.id] }),
}));

export const announcementsRelations = relations(announcements, ({ one }) => ({
  school: one(schools, { fields: [announcements.schoolId], references: [schools.id] }),
  author: one(users, { fields: [announcements.authorId], references: [users.id] }),
}));
