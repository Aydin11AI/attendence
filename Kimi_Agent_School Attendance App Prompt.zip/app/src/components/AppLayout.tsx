import { useState } from "react";
import { Link, useLocation } from "react-router";
import {
  LayoutDashboard, Users, GraduationCap, ClipboardCheck,
  Award, BookOpen, School, Bell, Search, Menu,
  ChevronRight, Settings, LogOut
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/students", label: "Students", icon: GraduationCap },
  { path: "/teachers", label: "Teachers", icon: Users },
  { path: "/attendance", label: "Attendance", icon: ClipboardCheck },
  { path: "/grades", label: "Grades", icon: Award },
  { path: "/classes", label: "Classes & Subjects", icon: BookOpen },
  { path: "/announcements", label: "Announcements", icon: Bell },
  { path: "/settings", label: "Settings", icon: Settings },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="flex h-screen bg-[#1a1a1e] overflow-hidden">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-50 w-64 bg-[#131316] border-r border-[rgba(244,244,245,0.08)] flex flex-col transition-transform duration-300 ease-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 h-[72px] border-b border-[rgba(244,244,245,0.08)]">
          <School className="w-7 h-7 text-[#c8ff2d]" />
          <span className="font-space text-lg font-medium tracking-wide text-[#f4f4f5]">
            NEXUS ACADEMY
          </span>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group",
                  isActive
                    ? "bg-[#c8ff2d]/10 text-[#c8ff2d] border border-[#c8ff2d]/20"
                    : "text-[#8f8f92] hover:text-[#f4f4f5] hover:bg-[rgba(255,255,255,0.03)] border border-transparent"
                )}
              >
                <item.icon className={cn("w-[18px] h-[18px]", isActive && "text-[#c8ff2d]")} />
                <span>{item.label}</span>
                {isActive && <ChevronRight className="w-4 h-4 ml-auto opacity-60" />}
              </Link>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="px-3 py-4 border-t border-[rgba(244,244,245,0.08)]">
          <button className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[#8f8f92] hover:text-[#f4f4f5] hover:bg-[rgba(255,255,255,0.03)] transition-all w-full">
            <LogOut className="w-[18px] h-[18px]" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="flex items-center justify-between px-4 lg:px-8 h-[72px] border-b border-[rgba(244,244,245,0.08)] bg-[#1a1a1e]/80 backdrop-blur-md sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#8f8f92] hover:text-[#f4f4f5] hover:bg-[rgba(255,255,255,0.05)]"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-full border border-[rgba(244,244,245,0.1)] bg-transparent w-80">
              <Search className="w-4 h-4 text-[#8f8f92]" />
              <input
                type="text"
                placeholder="Search students, classes..."
                className="bg-transparent text-sm text-[#f4f4f5] placeholder-[#8f8f92] outline-none w-full"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-lg text-[#8f8f92] hover:text-[#f4f4f5] hover:bg-[rgba(255,255,255,0.05)] transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#c8ff2d] rounded-full" />
            </button>
            <div className="flex items-center gap-3 pl-3 border-l border-[rgba(244,244,245,0.08)]">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#c8ff2d] to-[#2d8fff] flex items-center justify-center text-xs font-semibold text-[#1a1a1e]">
                AD
              </div>
              <div className="hidden lg:block">
                <p className="text-sm font-medium text-[#f4f4f5]">Admin</p>
                <p className="text-xs text-[#8f8f92]">Administrator</p>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
