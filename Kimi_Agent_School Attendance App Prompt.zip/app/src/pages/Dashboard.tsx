import { trpc } from "@/providers/trpc";
import {
  Users, GraduationCap, BookOpen, School,
  TrendingUp, TrendingDown, AlertTriangle, Award
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, PieChart, Pie
} from "recharts";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";

const COLORS = ["#c8ff2d", "#2d8fff", "#ffae2d", "#ff4d4d", "#a855f7", "#22d3ee"];

export default function Dashboard() {
  const { data: dashboard, isLoading: dLoading } = trpc.analytics.dashboard.useQuery();
  const { data: attendanceTrend } = trpc.analytics.attendanceTrend.useQuery({ period: "month" });
  const { data: gradeDist } = trpc.analytics.gradeDistribution.useQuery({});
  const { data: topPerformers } = trpc.analytics.topPerformers.useQuery({ limit: 10 });
  const { data: classPerf } = trpc.analytics.classPerformance.useQuery();

  const gradeDistData = gradeDist
    ? Object.entries(gradeDist).map(([name, value]) => ({ name, value })).filter((d) => d.value > 0)
    : [];

  const kpiCards = [
    {
      title: "Total Students",
      value: dashboard?.totalStudents ?? 0,
      icon: Users,
      color: "#c8ff2d",
      change: "+12%",
      up: true,
    },
    {
      title: "Total Teachers",
      value: dashboard?.totalTeachers ?? 0,
      icon: GraduationCap,
      color: "#2d8fff",
      change: "+3",
      up: true,
    },
    {
      title: "Classes",
      value: dashboard?.totalClasses ?? 0,
      icon: School,
      color: "#ffae2d",
      change: "0",
      up: true,
    },
    {
      title: "Avg GPA",
      value: dashboard?.avgGPA ?? "0.00",
      icon: Award,
      color: "#a855f7",
      change: "+0.15",
      up: true,
    },
    {
      title: "Today's Attendance",
      value: `${dashboard?.todayAttendanceRate ?? 0}%`,
      icon: BookOpen,
      color: "#22d3ee",
      change: "-2%",
      up: false,
    },
    {
      title: "Students at Risk",
      value: dashboard?.studentsAtRisk ?? 0,
      icon: AlertTriangle,
      color: "#ff4d4d",
      change: "+5",
      up: false,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">
          Dashboard
        </h1>
        <p className="text-sm text-[#8f8f92] mt-1">
          Welcome back! Here's what's happening at Nexus Academy.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {kpiCards.map((card, i) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05, duration: 0.4 }}
            className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-4 hover-border-neon"
          >
            <div className="flex items-center justify-between mb-3">
              <card.icon className="w-5 h-5" style={{ color: card.color }} />
              <span
                className={`flex items-center gap-0.5 text-xs font-medium ${
                  card.up ? "text-[#c8ff2d]" : "text-[#ff4d4d]"
                }`}
              >
                {card.up ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                {card.change}
              </span>
            </div>
            {dLoading ? (
              <Skeleton className="h-8 w-16 bg-[#3a3a3e]" />
            ) : (
              <p className="text-2xl font-medium font-space" style={{ color: card.color }}>
                {typeof card.value === "number" ? card.value.toLocaleString() : card.value}
              </p>
            )}
            <p className="text-xs text-[#8f8f92] mt-1">{card.title}</p>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance Trend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="lg:col-span-2 bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-5 hover-border-neon"
        >
          <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">
            Attendance Trend (30 Days)
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={attendanceTrend ?? []}>
              <defs>
                <linearGradient id="attGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#c8ff2d" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#c8ff2d" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(244,244,245,0.06)" />
              <XAxis
                dataKey="date"
                tickFormatter={(v) => {
                  if (!v) return "";
                  const d = new Date(v);
                  return `${d.getMonth() + 1}/${d.getDate()}`;
                }}
                stroke="#8f8f92"
                fontSize={11}
              />
              <YAxis domain={[0, 100]} stroke="#8f8f92" fontSize={11} unit="%" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#252529",
                  border: "1px solid rgba(244,244,245,0.1)",
                  borderRadius: "8px",
                  color: "#f4f4f5",
                }}
                formatter={(value: number) => [`${value}%`, "Attendance Rate"]}
              />
              <Area
                type="monotone"
                dataKey="rate"
                stroke="#c8ff2d"
                strokeWidth={2}
                fill="url(#attGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Grade Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-5 hover-border-neon"
        >
          <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">
            Grade Distribution
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={gradeDistData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {gradeDistData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "#252529",
                  border: "1px solid rgba(244,244,245,0.1)",
                  borderRadius: "8px",
                  color: "#f4f4f5",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-2 mt-2 justify-center">
            {gradeDistData.slice(0, 6).map((entry, i) => (
              <span key={entry.name} className="flex items-center gap-1 text-xs text-[#8f8f92]">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                {entry.name}
              </span>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Tables Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performers */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-5 hover-border-neon"
        >
          <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">
            Top Performers
          </h3>
          <div className="space-y-2">
            {(topPerformers ?? []).slice(0, 8).map((student, i) => (
              <div
                key={student.studentId}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg ${
                  i === 0 ? "bg-[#ffae2d]/5 border border-[#ffae2d]/20" : "hover:bg-[rgba(255,255,255,0.02)]"
                } transition-colors`}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold ${
                    i === 0
                      ? "bg-[#ffae2d] text-[#1a1a1e]"
                      : i === 1
                      ? "bg-[#8f8f92] text-[#1a1a1e]"
                      : i === 2
                      ? "bg-[#cd7f32] text-[#1a1a1e]"
                      : "bg-[#3a3a3e] text-[#8f8f92]"
                  }`}
                >
                  {i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#f4f4f5] truncate">{student.name}</p>
                  <p className="text-xs text-[#8f8f92]">{student.className}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold font-space text-[#c8ff2d]">{student.avgGpa}</p>
                  <p className="text-xs text-[#8f8f92]">{student.avgPercentage}%</p>
                </div>
              </div>
            ))}
            {(!topPerformers || topPerformers.length === 0) && (
              <div className="text-center py-8 text-[#8f8f92] text-sm">No data available</div>
            )}
          </div>
        </motion.div>

        {/* Class Performance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-5 hover-border-neon"
        >
          <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">
            Class Performance
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={(classPerf ?? []).slice(0, 12)}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(244,244,245,0.06)" />
              <XAxis
                dataKey="className"
                stroke="#8f8f92"
                fontSize={10}
                tickFormatter={(v) => v.replace("Grade ", "G")}
              />
              <YAxis stroke="#8f8f92" fontSize={11} domain={[0, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#252529",
                  border: "1px solid rgba(244,244,245,0.1)",
                  borderRadius: "8px",
                  color: "#f4f4f5",
                }}
              />
              <Bar dataKey="avgAttendance" fill="#c8ff2d" radius={[4, 4, 0, 0]} name="Attendance %" />
              <Bar dataKey="avgGPA" fill="#2d8fff" radius={[4, 4, 0, 0]} name="Avg GPA" />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2 justify-center">
            <span className="flex items-center gap-1 text-xs text-[#8f8f92]">
              <span className="w-3 h-3 rounded-sm bg-[#c8ff2d]" /> Attendance %
            </span>
            <span className="flex items-center gap-1 text-xs text-[#8f8f92]">
              <span className="w-3 h-3 rounded-sm bg-[#2d8fff]" /> Avg GPA x20
            </span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
