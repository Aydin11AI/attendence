import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Search, Plus, Trash2, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function Teachers() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const { data: teachersData, isLoading, refetch } = trpc.teacher.list.useQuery({
    search: search || undefined,
    page,
    limit: 20,
  });

  const createMutation = trpc.teacher.create.useMutation({
    onSuccess: () => { toast.success("Teacher created"); setShowAdd(false); refetch(); },
    onError: (err) => toast.error(err.message),
  });
  const deleteMutation = trpc.teacher.delete.useMutation({
    onSuccess: () => { toast.success("Teacher deleted"); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    createMutation.mutate({
      name: fd.get("name") as string,
      email: fd.get("email") as string,
      employeeId: fd.get("employeeId") as string,
      qualification: (fd.get("qualification") as string) || undefined,
      specialization: (fd.get("specialization") as string) || undefined,
      phone: (fd.get("phone") as string) || undefined,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">Teachers</h1>
          <p className="text-sm text-[#8f8f92] mt-1">Manage faculty and staff</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2">
          <Plus className="w-4 h-4" /> Add Teacher
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8f8f92]" />
        <Input
          placeholder="Search by name..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          className="pl-10 bg-[#252529] border-[rgba(244,244,245,0.08)] text-[#f4f4f5] placeholder:text-[#8f8f92]"
        />
      </div>

      <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[rgba(244,244,245,0.08)]">
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Teacher</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Employee ID</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Specialization</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Qualification</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Status</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-8 bg-[#3a3a3e]" /></td></tr>
                ))
              ) : (
                (teachersData?.teachers ?? []).map((t) => (
                  <tr key={t.id} className="border-b border-[rgba(244,244,245,0.05)] hover:bg-[rgba(255,255,255,0.02)] transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#ffae2d] to-[#c8ff2d] flex items-center justify-center text-xs font-semibold text-[#1a1a1e]">
                          {t.name?.split(" ").map((n: string) => n[0]).join("") ?? "?"}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-[#f4f4f5]">{t.name}</p>
                          <p className="text-xs text-[#8f8f92]">{t.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#8f8f92] font-mono">{t.employeeId}</td>
                    <td className="px-4 py-3 text-sm text-[#f4f4f5]">{t.specialization ?? "—"}</td>
                    <td className="px-4 py-3 text-sm text-[#8f8f92]">{t.qualification ?? "—"}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-[#c8ff2d]/10 text-[#c8ff2d]">{t.status}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => { if (confirm("Delete this teacher?")) deleteMutation.mutate({ id: t.id }); }} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#ff4d4d] hover:bg-[rgba(255,77,77,0.1)] transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {teachersData && teachersData.totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[rgba(244,244,245,0.08)]">
            <p className="text-xs text-[#8f8f92]">Page {teachersData.page} of {teachersData.totalPages}</p>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="border-[rgba(244,244,245,0.1)] text-[#f4f4f5]"><ChevronLeft className="w-4 h-4" /></Button>
              <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.min(teachersData.totalPages, p + 1))} disabled={page === teachersData.totalPages} className="border-[rgba(244,244,245,0.1)] text-[#f4f4f5]"><ChevronRight className="w-4 h-4" /></Button>
            </div>
          </div>
        )}
      </div>

      {/* Add Dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="bg-[#252529] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] max-w-lg">
          <DialogHeader><DialogTitle className="font-space">Add New Teacher</DialogTitle></DialogHeader>
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Name *</label><Input name="name" required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Email *</label><Input name="email" type="email" required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Employee ID *</label><Input name="employeeId" required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Phone</label><Input name="phone" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Qualification</label><Input name="qualification" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Specialization</label><Input name="specialization" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
            </div>
            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => setShowAdd(false)} className="border-[rgba(244,244,245,0.15)] text-[#f4f4f5]">Cancel</Button>
              <Button type="submit" className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium" disabled={createMutation.isPending}>Create</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
