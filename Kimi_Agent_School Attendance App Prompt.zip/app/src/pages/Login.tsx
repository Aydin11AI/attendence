import { School } from "lucide-react";
import { Button } from "@/components/ui/button";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#1a1a1e]">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#c8ff2d] to-[#2d8fff] flex items-center justify-center mx-auto mb-4">
            <School className="w-8 h-8 text-[#1a1a1e]" />
          </div>
          <h1 className="text-2xl font-light text-[#f4f4f5] font-space tracking-tight">
            NEXUS ACADEMY
          </h1>
          <p className="text-sm text-[#8f8f92] mt-2">
            School Attendance & Grade Management
          </p>
        </div>

        <div className="bg-[#252529] rounded-2xl border border-[rgba(244,244,245,0.08)] p-6">
          <h2 className="text-base font-medium text-[#f4f4f5] text-center mb-6">
            Sign in to your account
          </h2>
          <Button
            className="w-full bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium h-11"
            size="lg"
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
          >
            Sign in with Kimi
          </Button>
          <p className="text-xs text-[#8f8f92] text-center mt-4">
            By signing in, you agree to our Terms of Service and Privacy Policy.
          </p>
        </div>

        <p className="text-xs text-[#8f8f92] text-center mt-6">
          Nexus Academy v1.0.0
        </p>
      </div>
    </div>
  );
}
