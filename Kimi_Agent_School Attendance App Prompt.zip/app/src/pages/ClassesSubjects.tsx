import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { BookOpen, Plus, Pencil, Trash2, School, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

export default function ClassesSubjects() {
  const [tab, setTab] = useState("classes");
  const [showAdd, setShowAdd] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);

  const { data: classesData, refetch: refetchClasses } = trpc.classSubject.listClasses.useQuery({});
  const { data: subjectsData, refetch: refetchSubjects } = trpc.classSubject.listSubjects.useQuery({});

  const createClass = trpc.classSubject.createClass.useMutation({
    onSuccess: () => { toast.success("Class created"); setShowAdd(false); refetchClasses(); },
    onError: (err) => toast.error(err.message),
  });
  const updateClass = trpc.classSubject.updateClass.useMutation({
    onSuccess: () => { toast.success("Class updated"); setEditItem(null); refetchClasses(); },
    onError: (err) => toast.error(err.message),
  });
  const deleteClass = trpc.classSubject.deleteClass.useMutation({
    onSuccess: () => { toast.success("Class deleted"); refetchClasses(); },
    onError: (err) => toast.error(err.message),
  });

  const createSubject = trpc.classSubject.createSubject.useMutation({
    onSuccess: () => { toast.success("Subject created"); setShowAdd(false); refetchSubjects(); },
    onError: (err) => toast.error(err.message),
  });
  const updateSubject = trpc.classSubject.updateSubject.useMutation({
    onSuccess: () => { toast.success("Subject updated"); setEditItem(null); refetchSubjects(); },
    onError: (err) => toast.error(err.message),
  });
  const deleteSubject = trpc.classSubject.deleteSubject.useMutation({
    onSuccess: () => { toast.success("Subject deleted"); refetchSubjects(); },
    onError: (err) => toast.error(err.message),
  });

  const handleClassSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (editItem) {
      updateClass.mutate({ id: editItem.id, name: fd.get("name") as string, gradeLevel: Number(fd.get("gradeLevel")), section: fd.get("section") as string });
    } else {
      createClass.mutate({ schoolId: 1, name: fd.get("name") as string, gradeLevel: Number(fd.get("gradeLevel")), section: fd.get("section") as string, academicYear: "2025-2026" });
    }
  };

  const handleSubjectSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (editItem) {
      updateSubject.mutate({ id: editItem.id, name: fd.get("name") as string, code: fd.get("code") as string, credits: Number(fd.get("credits")) });
    } else {
      createSubject.mutate({ schoolId: 1, name: fd.get("name") as string, code: fd.get("code") as string, credits: Number(fd.get("credits")) });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">Classes & Subjects</h1>
        <p className="text-sm text-[#8f8f92] mt-1">Manage classes and curriculum</p>
      </div>

      <Tabs value={tab} onValueChange={(v) => { setTab(v); setEditItem(null); }}>
        <TabsList className="bg-[#252529] border border-[rgba(244,244,245,0.08)]">
          <TabsTrigger value="classes" className="data-[state=active]:bg-[#c8ff2d] data-[state=active]:text-[#1a1a1e] text-[#8f8f92]">
            <School className="w-4 h-4 mr-2" /> Classes
          </TabsTrigger>
          <TabsTrigger value="subjects" className="data-[state=active]:bg-[#c8ff2d] data-[state=active]:text-[#1a1a1e] text-[#8f8f92]">
            <BookOpen className="w-4 h-4 mr-2" /> Subjects
          </TabsTrigger>
        </TabsList>

        <TabsContent value="classes" className="mt-4">
          <div className="flex justify-end mb-4">
            <Button onClick={() => { setEditItem(null); setShowAdd(true); }} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2">
              <Plus className="w-4 h-4" /> Add Class
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(classesData ?? []).map((c) => (
              <div key={c.id} className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-5 hover-border-neon group">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-lg bg-[#c8ff2d]/10 flex items-center justify-center">
                    <GraduationCap className="w-5 h-5 text-[#c8ff2d]" />
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => { setEditItem(c); setTab("classes"); setShowAdd(true); }} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#c8ff2d]"><Pencil className="w-3.5 h-3.5" /></button>
                    <button onClick={() => { if (confirm("Delete?")) deleteClass.mutate({ id: c.id }); }} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#ff4d4d]"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
                <h3 className="text-lg font-medium text-[#f4f4f5] font-space">{c.name}</h3>
                <div className="flex gap-3 mt-2 text-xs text-[#8f8f92]">
                  <span>Grade {c.gradeLevel}</span>
                  <span>Section {c.section}</span>
                  <span>Room {c.roomNumber}</span>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="subjects" className="mt-4">
          <div className="flex justify-end mb-4">
            <Button onClick={() => { setEditItem(null); setShowAdd(true); }} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2">
              <Plus className="w-4 h-4" /> Add Subject
            </Button>
          </div>
          <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[rgba(244,244,245,0.08)]">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Code</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Name</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Credits</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Status</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(subjectsData ?? []).map((s) => (
                  <tr key={s.id} className="border-b border-[rgba(244,244,245,0.05)] hover:bg-[rgba(255,255,255,0.02)]">
                    <td className="px-4 py-3 text-sm font-mono text-[#c8ff2d]">{s.code}</td>
                    <td className="px-4 py-3 text-sm text-[#f4f4f5]">{s.name}</td>
                    <td className="px-4 py-3 text-sm text-[#8f8f92]">{s.credits}</td>
                    <td className="px-4 py-3"><span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-[#c8ff2d]/10 text-[#c8ff2d]">{s.status}</span></td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => { setEditItem(s); setTab("subjects"); setShowAdd(true); }} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#c8ff2d]"><Pencil className="w-3.5 h-3.5" /></button>
                        <button onClick={() => { if (confirm("Delete?")) deleteSubject.mutate({ id: s.id }); }} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#ff4d4d]"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="bg-[#252529] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] max-w-md">
          <DialogHeader><DialogTitle className="font-space">{editItem ? "Edit" : "Add"} {tab === "classes" ? "Class" : "Subject"}</DialogTitle></DialogHeader>
          {tab === "classes" ? (
            <form onSubmit={handleClassSubmit} className="space-y-4">
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Name *</label><Input name="name" defaultValue={editItem?.name ?? ""} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-xs text-[#8f8f92] mb-1 block">Grade Level *</label><Input name="gradeLevel" type="number" min={1} max={12} defaultValue={editItem?.gradeLevel ?? ""} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
                <div><label className="text-xs text-[#8f8f92] mb-1 block">Section</label><Input name="section" defaultValue={editItem?.section ?? ""} className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              </div>
              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setShowAdd(false)} className="border-[rgba(244,244,245,0.15)] text-[#f4f4f5]">Cancel</Button>
                <Button type="submit" className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d]">{editItem ? "Update" : "Create"}</Button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleSubjectSubmit} className="space-y-4">
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Name *</label><Input name="name" defaultValue={editItem?.name ?? ""} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-xs text-[#8f8f92] mb-1 block">Code *</label><Input name="code" defaultValue={editItem?.code ?? ""} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
                <div><label className="text-xs text-[#8f8f92] mb-1 block">Credits *</label><Input name="credits" type="number" min={1} max={10} defaultValue={editItem?.credits ?? 1} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              </div>
              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setShowAdd(false)} className="border-[rgba(244,244,245,0.15)] text-[#f4f4f5]">Cancel</Button>
                <Button type="submit" className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d]">{editItem ? "Update" : "Create"}</Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
