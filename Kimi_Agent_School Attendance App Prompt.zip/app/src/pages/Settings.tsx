import { useState } from "react";
import { User, Shield, Palette, Database, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("profile");

  const handleSave = () => {
    toast.success("Settings saved successfully");
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">Settings</h1>
        <p className="text-sm text-[#8f8f92] mt-1">Manage your account and application preferences</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-[#252529] border border-[rgba(244,244,245,0.08)]">
          <TabsTrigger value="profile" className="data-[state=active]:bg-[#c8ff2d] data-[state=active]:text-[#1a1a1e] text-[#8f8f92]">
            <User className="w-4 h-4 mr-2" /> Profile
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-[#c8ff2d] data-[state=active]:text-[#1a1a1e] text-[#8f8f92]">
            <Shield className="w-4 h-4 mr-2" /> Security
          </TabsTrigger>
          <TabsTrigger value="appearance" className="data-[state=active]:bg-[#c8ff2d] data-[state=active]:text-[#1a1a1e] text-[#8f8f92]">
            <Palette className="w-4 h-4 mr-2" /> Appearance
          </TabsTrigger>
          <TabsTrigger value="system" className="data-[state=active]:bg-[#c8ff2d] data-[state=active]:text-[#1a1a1e] text-[#8f8f92]">
            <Database className="w-4 h-4 mr-2" /> System
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-6 space-y-6">
          <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-6">
            <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">Profile Information</h3>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#c8ff2d] to-[#2d8fff] flex items-center justify-center text-lg font-semibold text-[#1a1a1e]">
                AD
              </div>
              <div>
                <p className="text-sm font-medium text-[#f4f4f5]">Administrator</p>
                <p className="text-xs text-[#8f8f92]">admin@nexusacademy.edu</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Display Name</label><Input defaultValue="Administrator" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Email</label><Input defaultValue="admin@nexusacademy.edu" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Phone</label><Input defaultValue="+1 (555) 123-4567" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Role</label><Input defaultValue="Administrator" disabled className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#8f8f92]" /></div>
            </div>
          </div>
          <Button onClick={handleSave} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2">
            <Save className="w-4 h-4" /> Save Changes
          </Button>
        </TabsContent>

        <TabsContent value="security" className="mt-6 space-y-6">
          <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-6">
            <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">Change Password</h3>
            <div className="space-y-4 max-w-md">
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Current Password</label><Input type="password" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">New Password</label><Input type="password" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
              <div><label className="text-xs text-[#8f8f92] mb-1 block">Confirm New Password</label><Input type="password" className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
            </div>
          </div>
          <Button onClick={handleSave} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2">
            <Save className="w-4 h-4" /> Update Password
          </Button>
        </TabsContent>

        <TabsContent value="appearance" className="mt-6 space-y-6">
          <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-6">
            <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">Theme Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-[rgba(244,244,245,0.05)]">
                <div>
                  <p className="text-sm text-[#f4f4f5]">Dark Mode</p>
                  <p className="text-xs text-[#8f8f92]">Use the dark color scheme</p>
                </div>
                <div className="w-11 h-6 rounded-full bg-[#c8ff2d] relative cursor-pointer">
                  <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-[#1a1a1e]" />
                </div>
              </div>
              <div className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm text-[#f4f4f5]">Compact View</p>
                  <p className="text-xs text-[#8f8f92]">Reduce spacing in tables and lists</p>
                </div>
                <div className="w-11 h-6 rounded-full bg-[#3a3a3e] relative cursor-pointer">
                  <div className="absolute left-1 top-1 w-4 h-4 rounded-full bg-[#8f8f92]" />
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="system" className="mt-6 space-y-6">
          <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-6">
            <h3 className="text-sm font-medium text-[#f4f4f5] mb-4 font-space">System Information</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-2 border-b border-[rgba(244,244,245,0.05)]">
                <span className="text-[#8f8f92]">Application Version</span>
                <span className="text-[#f4f4f5] font-mono">1.0.0</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[rgba(244,244,245,0.05)]">
                <span className="text-[#8f8f92]">Database</span>
                <span className="text-[#f4f4f5] font-mono">MySQL</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[rgba(244,244,245,0.05)]">
                <span className="text-[#8f8f92]">API Framework</span>
                <span className="text-[#f4f4f5] font-mono">tRPC + Hono</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-[#8f8f92]">Frontend</span>
                <span className="text-[#f4f4f5] font-mono">React 19 + Tailwind</span>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
