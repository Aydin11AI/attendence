import { useState } from "react";
import { trpc } from "@/providers/trpc";

import {
  Search, Plus, ChevronLeft, ChevronRight, Pencil, Trash2,
  GraduationCap, Mail, Phone, MapPin, User
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function Students() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [classFilter, setClassFilter] = useState<string>("");
  const [showAdd, setShowAdd] = useState(false);
  const [editStudent, setEditStudent] = useState<any>(null);
  const [viewStudent, setViewStudent] = useState<any>(null);

  const { data: studentsData, isLoading, refetch } = trpc.student.list.useQuery({
    search: search || undefined,
    classId: classFilter ? Number(classFilter) : undefined,
    page,
    limit: 20,
  });
  const { data: classesData } = trpc.classSubject.listClasses.useQuery({});
  const utils = trpc.useUtils();

  const createMutation = trpc.student.create.useMutation({
    onSuccess: () => {
      toast.success("Student created successfully");
      setShowAdd(false);
      refetch();
      utils.analytics.dashboard.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const updateMutation = trpc.student.update.useMutation({
    onSuccess: () => {
      toast.success("Student updated successfully");
      setEditStudent(null);
      refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.student.delete.useMutation({
    onSuccess: () => {
      toast.success("Student deleted successfully");
      refetch();
      utils.analytics.dashboard.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    createMutation.mutate({
      name: fd.get("name") as string,
      email: fd.get("email") as string,
      studentId: fd.get("studentId") as string,
      classId: Number(fd.get("classId")),
      rollNumber: fd.get("rollNumber") ? Number(fd.get("rollNumber")) : undefined,
      gender: (fd.get("gender") as "male" | "female" | "other") || undefined,
      parentName: (fd.get("parentName") as string) || undefined,
      parentPhone: (fd.get("parentPhone") as string) || undefined,
      parentEmail: (fd.get("parentEmail") as string) || undefined,
    });
  };

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: editStudent.id,
      name: (fd.get("name") as string) || undefined,
      email: (fd.get("email") as string) || undefined,
      classId: fd.get("classId") ? Number(fd.get("classId")) : undefined,
      parentName: (fd.get("parentName") as string) || undefined,
      parentPhone: (fd.get("parentPhone") as string) || undefined,
    });
  };

  const studentForm = (student?: any, onSubmit?: (e: React.FormEvent<HTMLFormElement>) => void) => (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Full Name *</label>
          <Input name="name" defaultValue={student?.name ?? ""} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" />
        </div>
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Email *</label>
          <Input name="email" type="email" defaultValue={student?.email ?? ""} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" />
        </div>
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Student ID *</label>
          <Input name="studentId" defaultValue={student?.studentId ?? ""} required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" />
        </div>
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Class *</label>
          <Select name="classId" defaultValue={student?.classId?.toString() ?? ""}>
            <SelectTrigger className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]">
              <SelectValue placeholder="Select class" />
            </SelectTrigger>
            <SelectContent className="bg-[#252529] border-[rgba(244,244,245,0.1)]">
              {(classesData ?? []).map((c) => (
                <SelectItem key={c.id} value={c.id.toString()} className="text-[#f4f4f5] focus:bg-[#3a3a3e] focus:text-[#f4f4f5]">
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Roll Number</label>
          <Input name="rollNumber" type="number" defaultValue={student?.rollNumber ?? ""} className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" />
        </div>
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Gender</label>
          <Select name="gender" defaultValue={student?.gender ?? ""}>
            <SelectTrigger className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]">
              <SelectValue placeholder="Select" />
            </SelectTrigger>
            <SelectContent className="bg-[#252529] border-[rgba(244,244,245,0.1)]">
              <SelectItem value="male" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Male</SelectItem>
              <SelectItem value="female" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Female</SelectItem>
              <SelectItem value="other" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Parent Name</label>
          <Input name="parentName" defaultValue={student?.parentName ?? ""} className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" />
        </div>
        <div>
          <label className="text-xs text-[#8f8f92] mb-1 block">Parent Phone</label>
          <Input name="parentPhone" defaultValue={student?.parentPhone ?? ""} className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" />
        </div>
        <div className="col-span-2">
          <label className="text-xs text-[#8f8f92] mb-1 block">Parent Email</label>
          <Input name="parentEmail" type="email" defaultValue={student?.parentEmail ?? ""} className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" />
        </div>
      </div>
      <div className="flex justify-end gap-3 pt-2">
        <Button type="button" variant="outline" onClick={() => { setShowAdd(false); setEditStudent(null); }} className="border-[rgba(244,244,245,0.15)] text-[#f4f4f5] hover:bg-[rgba(255,255,255,0.05)]">
          Cancel
        </Button>
        <Button type="submit" className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium" disabled={createMutation.isPending || updateMutation.isPending}>
          {student ? "Update" : "Create"} Student
        </Button>
      </div>
    </form>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">Students</h1>
          <p className="text-sm text-[#8f8f92] mt-1">Manage student records and profiles</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2">
          <Plus className="w-4 h-4" /> Add Student
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8f8f92]" />
          <Input
            placeholder="Search by name..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="pl-10 bg-[#252529] border-[rgba(244,244,245,0.08)] text-[#f4f4f5] placeholder:text-[#8f8f92]"
          />
        </div>
        <Select value={classFilter} onValueChange={(v) => { setClassFilter(v); setPage(1); }}>
          <SelectTrigger className="w-48 bg-[#252529] border-[rgba(244,244,245,0.08)] text-[#f4f4f5]">
            <SelectValue placeholder="All Classes" />
          </SelectTrigger>
          <SelectContent className="bg-[#252529] border-[rgba(244,244,245,0.1)]">
            <SelectItem value="all" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">All Classes</SelectItem>
            {(classesData ?? []).map((c) => (
              <SelectItem key={c.id} value={c.id.toString()} className="text-[#f4f4f5] focus:bg-[#3a3a3e]">{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[rgba(244,244,245,0.08)]">
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase tracking-wider">Student</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase tracking-wider">ID</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase tracking-wider">Class</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase tracking-wider">Gender</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase tracking-wider">Parent</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase tracking-wider">Status</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-8 bg-[#3a3a3e]" /></td></tr>
                ))
              ) : (
                (studentsData?.students ?? []).map((s) => (
                  <tr key={s.id} className="border-b border-[rgba(244,244,245,0.05)] hover:bg-[rgba(255,255,255,0.02)] transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#2d8fff] to-[#c8ff2d] flex items-center justify-center text-xs font-semibold text-[#1a1a1e]">
                          {s.name?.split(" ").map((n: string) => n[0]).join("") ?? "?"}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-[#f4f4f5]">{s.name}</p>
                          <p className="text-xs text-[#8f8f92]">{s.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#8f8f92] font-mono">{s.studentId}</td>
                    <td className="px-4 py-3 text-sm text-[#f4f4f5]">{s.className}</td>
                    <td className="px-4 py-3 text-sm text-[#8f8f92] capitalize">{s.gender}</td>
                    <td className="px-4 py-3 text-sm text-[#8f8f92]">{s.parentName ?? "—"}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${
                        s.status === "active" ? "bg-[#c8ff2d]/10 text-[#c8ff2d]" : "bg-[#ff4d4d]/10 text-[#ff4d4d]"
                      }`}>
                        {s.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => setViewStudent(s)} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#2d8fff] hover:bg-[rgba(45,143,255,0.1)] transition-colors">
                          <GraduationCap className="w-4 h-4" />
                        </button>
                        <button onClick={() => setEditStudent(s)} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#c8ff2d] hover:bg-[rgba(200,255,45,0.1)] transition-colors">
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => { if (confirm("Delete this student?")) deleteMutation.mutate({ id: s.id }); }} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#ff4d4d] hover:bg-[rgba(255,77,77,0.1)] transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {studentsData && studentsData.totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[rgba(244,244,245,0.08)]">
            <p className="text-xs text-[#8f8f92]">Page {studentsData.page} of {studentsData.totalPages}</p>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="border-[rgba(244,244,245,0.1)] text-[#f4f4f5] hover:bg-[rgba(255,255,255,0.05)]">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.min(studentsData.totalPages, p + 1))} disabled={page === studentsData.totalPages} className="border-[rgba(244,244,245,0.1)] text-[#f4f4f5] hover:bg-[rgba(255,255,255,0.05)]">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Add Dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="bg-[#252529] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="font-space">Add New Student</DialogTitle></DialogHeader>
          {studentForm(undefined, handleCreate)}
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editStudent} onOpenChange={() => setEditStudent(null)}>
        <DialogContent className="bg-[#252529] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="font-space">Edit Student</DialogTitle></DialogHeader>
          {editStudent && studentForm(editStudent, handleUpdate)}
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewStudent} onOpenChange={() => setViewStudent(null)}>
        <DialogContent className="bg-[#252529] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] max-w-md">
          <DialogHeader><DialogTitle className="font-space">Student Profile</DialogTitle></DialogHeader>
          {viewStudent && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#2d8fff] to-[#c8ff2d] flex items-center justify-center text-lg font-semibold text-[#1a1a1e]">
                  {viewStudent.name?.split(" ").map((n: string) => n[0]).join("")}
                </div>
                <div>
                  <h3 className="text-lg font-medium text-[#f4f4f5]">{viewStudent.name}</h3>
                  <p className="text-sm text-[#8f8f92]">{viewStudent.studentId}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2 text-[#8f8f92]"><Mail className="w-4 h-4" /> {viewStudent.email}</div>
                <div className="flex items-center gap-2 text-[#8f8f92]"><User className="w-4 h-4" /> {viewStudent.gender}</div>
                <div className="flex items-center gap-2 text-[#8f8f92]"><GraduationCap className="w-4 h-4" /> {viewStudent.className}</div>
                <div className="flex items-center gap-2 text-[#8f8f92]"><Phone className="w-4 h-4" /> {viewStudent.parentPhone ?? "—"}</div>
                <div className="col-span-2 flex items-center gap-2 text-[#8f8f92]"><MapPin className="w-4 h-4" /> {viewStudent.parentName ?? "—"}</div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
