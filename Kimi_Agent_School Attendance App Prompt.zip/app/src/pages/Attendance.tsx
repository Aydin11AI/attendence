import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { format } from "date-fns";
import { CalendarDays, Check, X, Clock, AlertCircle, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { motion } from "framer-motion";

type AttendanceStatus = "present" | "absent" | "late" | "excused";

const statusConfig: Record<AttendanceStatus, { label: string; color: string; bg: string; icon: typeof Check }> = {
  present: { label: "Present", color: "#c8ff2d", bg: "rgba(200,255,45,0.15)", icon: Check },
  absent: { label: "Absent", color: "#ff4d4d", bg: "rgba(255,77,77,0.15)", icon: X },
  late: { label: "Late", color: "#ffae2d", bg: "rgba(255,174,45,0.15)", icon: Clock },
  excused: { label: "Excused", color: "#2d8fff", bg: "rgba(45,143,255,0.15)", icon: AlertCircle },
};

export default function Attendance() {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [attendanceMap, setAttendanceMap] = useState<Record<number, AttendanceStatus>>({});

  const { data: classesData } = trpc.classSubject.listClasses.useQuery({});
  const { data: attendanceData, isLoading } = trpc.attendance.getByDate.useQuery(
    { date: selectedDate, classId: Number(selectedClass) },
    { enabled: !!selectedClass }
  );
  const { data: stats } = trpc.attendance.getStats.useQuery(
    { classId: selectedClass ? Number(selectedClass) : undefined, period: "week" },
    { enabled: !!selectedClass }
  );

  const bulkMarkMutation = trpc.attendance.bulkMark.useMutation({
    onSuccess: () => { toast.success("Attendance saved!"); setAttendanceMap({}); },
    onError: (err) => toast.error(err.message),
  });

  // Initialize from loaded data
  const mergedData = (attendanceData ?? []).map((s) => ({
    ...s,
    currentStatus: attendanceMap[s.studentId] ?? (s.status === "unmarked" ? undefined : s.status as AttendanceStatus) ?? undefined,
  }));

  const setStatus = (studentId: number, status: AttendanceStatus) => {
    setAttendanceMap((prev) => ({ ...prev, [studentId]: status }));
  };

  const handleSave = () => {
    if (!selectedClass) return;
    const records = Object.entries(attendanceMap).map(([studentId, status]) => ({
      studentId: Number(studentId),
      status,
    }));
    if (records.length === 0) { toast.error("No changes to save"); return; }
    bulkMarkMutation.mutate({
      classId: Number(selectedClass),
      teacherId: 1,
      date: selectedDate,
      records,
    });
  };

  const presentCount = mergedData.filter((s) => s.currentStatus === "present").length;
  const absentCount = mergedData.filter((s) => s.currentStatus === "absent").length;
  const lateCount = mergedData.filter((s) => s.currentStatus === "late").length;
  const totalMarked = presentCount + absentCount + lateCount + mergedData.filter((s) => s.currentStatus === "excused").length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">Attendance</h1>
        <p className="text-sm text-[#8f8f92] mt-1">Mark and track daily attendance</p>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#252529] border border-[rgba(244,244,245,0.08)]">
          <CalendarDays className="w-4 h-4 text-[#8f8f92]" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-transparent text-sm text-[#f4f4f5] outline-none"
          />
        </div>
        <Select value={selectedClass} onValueChange={setSelectedClass}>
          <SelectTrigger className="w-56 bg-[#252529] border-[rgba(244,244,245,0.08)] text-[#f4f4f5]">
            <SelectValue placeholder="Select Class" />
          </SelectTrigger>
          <SelectContent className="bg-[#252529] border-[rgba(244,244,245,0.1)]">
            {(classesData ?? []).map((c) => (
              <SelectItem key={c.id} value={c.id.toString()} className="text-[#f4f4f5] focus:bg-[#3a3a3e]">{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {Object.keys(attendanceMap).length > 0 && (
          <Button onClick={handleSave} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2" disabled={bulkMarkMutation.isPending}>
            <Save className="w-4 h-4" /> Save Changes ({Object.keys(attendanceMap).length})
          </Button>
        )}
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Present Rate", value: `${stats.presentRate}%`, color: "#c8ff2d" },
            { label: "Absent Rate", value: `${stats.absentRate}%`, color: "#ff4d4d" },
            { label: "Late Rate", value: `${stats.lateRate}%`, color: "#ffae2d" },
            { label: "Total Records", value: stats.total.toString(), color: "#2d8fff" },
          ].map((s) => (
            <div key={s.label} className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-4">
              <p className="text-xs text-[#8f8f92]">{s.label}</p>
              <p className="text-xl font-medium font-space mt-1" style={{ color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Attendance Grid */}
      {selectedClass ? (
        <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] overflow-hidden">
          {/* Mini summary */}
          {mergedData.length > 0 && (
            <div className="flex items-center gap-6 px-5 py-3 border-b border-[rgba(244,244,245,0.08)] bg-[rgba(255,255,255,0.01)]">
              <span className="text-xs text-[#8f8f92]">
                Marked: <span className="text-[#f4f4f5] font-medium">{totalMarked}</span> / {mergedData.length}
              </span>
              <div className="flex gap-3">
                <span className="flex items-center gap-1 text-xs text-[#c8ff2d]"><span className="w-2 h-2 rounded-full bg-[#c8ff2d]" />{presentCount} Present</span>
                <span className="flex items-center gap-1 text-xs text-[#ff4d4d]"><span className="w-2 h-2 rounded-full bg-[#ff4d4d]" />{absentCount} Absent</span>
                <span className="flex items-center gap-1 text-xs text-[#ffae2d]"><span className="w-2 h-2 rounded-full bg-[#ffae2d]" />{lateCount} Late</span>
              </div>
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[rgba(244,244,245,0.08)]">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Student</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Roll #</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Present</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Absent</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Late</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Excused</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Status</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-10 bg-[#3a3a3e]" /></td></tr>
                  ))
                ) : (
                  mergedData.map((s, i) => (
                    <motion.tr
                      key={s.studentId}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: i * 0.02 }}
                      className="border-b border-[rgba(244,244,245,0.05)] hover:bg-[rgba(255,255,255,0.02)]"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#2d8fff] to-[#c8ff2d] flex items-center justify-center text-[10px] font-bold text-[#1a1a1e]">
                            {s.studentName?.split(" ").map((n: string) => n[0]).join("")}
                          </div>
                          <span className="text-sm text-[#f4f4f5]">{s.studentName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-[#8f8f92] font-mono">{s.rollNumber ?? "—"}</td>
                      {(["present", "absent", "late", "excused"] as AttendanceStatus[]).map((status) => {
                        const config = statusConfig[status];
                        const isActive = s.currentStatus === status;
                        return (
                          <td key={status} className="px-4 py-3 text-center">
                            <motion.button
                              whileTap={{ scale: 0.9 }}
                              onClick={() => setStatus(s.studentId, status)}
                              className="inline-flex items-center justify-center w-8 h-8 rounded-lg transition-all"
                              style={{
                                backgroundColor: isActive ? config.bg : "transparent",
                                border: `1.5px solid ${isActive ? config.color : "rgba(244,244,245,0.1)"}`,
                              }}
                            >
                              <config.icon className="w-3.5 h-3.5" style={{ color: isActive ? config.color : "#8f8f92" }} />
                            </motion.button>
                          </td>
                        );
                      })}
                      <td className="px-4 py-3">
                        {s.currentStatus ? (
                          <span
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                            style={{ backgroundColor: statusConfig[s.currentStatus as AttendanceStatus].bg, color: statusConfig[s.currentStatus as AttendanceStatus].color }}
                          >
                            {statusConfig[s.currentStatus as AttendanceStatus].label}
                          </span>
                        ) : (
                          <span className="text-xs text-[#8f8f92]">Not marked</span>
                        )}
                      </td>
                    </motion.tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {mergedData.length === 0 && !isLoading && (
            <div className="text-center py-12 text-[#8f8f92] text-sm">No students found in this class</div>
          )}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-[#8f8f92]">
          <CalendarDays className="w-12 h-12 mb-3 opacity-40" />
          <p className="text-sm">Select a class to view and mark attendance</p>
        </div>
      )}
    </div>
  );
}
