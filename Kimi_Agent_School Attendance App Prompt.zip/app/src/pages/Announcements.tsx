import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Bell, Plus, Trash2, Megaphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function Announcements() {
  const [showAdd, setShowAdd] = useState(false);
  const { data: announcementsData, refetch } = trpc.announcement.list.useQuery({});
  const createMutation = trpc.announcement.create.useMutation({
    onSuccess: () => { toast.success("Announcement posted"); setShowAdd(false); refetch(); },
    onError: (err) => toast.error(err.message),
  });
  const deleteMutation = trpc.announcement.delete.useMutation({
    onSuccess: () => { toast.success("Announcement deleted"); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    createMutation.mutate({
      title: fd.get("title") as string,
      content: fd.get("content") as string,
      authorId: 1,
      targetRole: (fd.get("targetRole") as any) || "all",
      priority: (fd.get("priority") as any) || "medium",
    });
  };

  const priorityColors: Record<string, string> = {
    low: "#8f8f92",
    medium: "#2d8fff",
    high: "#ffae2d",
    urgent: "#ff4d4d",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">Announcements</h1>
          <p className="text-sm text-[#8f8f92] mt-1">School-wide communications and notices</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2">
          <Plus className="w-4 h-4" /> New Announcement
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {(announcementsData ?? []).map((a) => (
          <div key={a.id} className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] p-5 hover-border-neon group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${priorityColors[a.priority ?? "medium"]}15` }}>
                  <Megaphone className="w-5 h-5" style={{ color: priorityColors[a.priority ?? "medium"] }} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-medium text-[#f4f4f5]">{a.title}</h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-medium uppercase" style={{ backgroundColor: `${priorityColors[a.priority ?? "medium"]}15`, color: priorityColors[a.priority ?? "medium"] }}>
                      {a.priority}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-[#2d8fff]/10 text-[#2d8fff] uppercase">
                      {a.targetRole}
                    </span>
                  </div>
                  <p className="text-xs text-[#8f8f92] mt-0.5">By {a.authorName} · {a.createdAt ? new Date(a.createdAt).toLocaleDateString() : ""}</p>
                </div>
              </div>
              <button onClick={() => { if (confirm("Delete?")) deleteMutation.mutate({ id: a.id }); }} className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#ff4d4d] opacity-0 group-hover:opacity-100 transition-all">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8f8f92] mt-3 leading-relaxed">{a.content}</p>
          </div>
        ))}
        {(!announcementsData || announcementsData.length === 0) && (
          <div className="text-center py-16 text-[#8f8f92]">
            <Bell className="w-10 h-10 mx-auto mb-3 opacity-40" />
            <p className="text-sm">No announcements yet</p>
          </div>
        )}
      </div>

      {/* Add Dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="bg-[#252529] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] max-w-lg">
          <DialogHeader><DialogTitle className="font-space">New Announcement</DialogTitle></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div><label className="text-xs text-[#8f8f92] mb-1 block">Title *</label><Input name="title" required className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]" /></div>
            <div><label className="text-xs text-[#8f8f92] mb-1 block">Content *</label><textarea name="content" required rows={4} className="w-full rounded-md bg-[#1a1a1e] border border-[rgba(244,244,245,0.1)] text-[#f4f4f5] p-3 text-sm outline-none focus:ring-1 focus:ring-[#c8ff2d] resize-none" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-[#8f8f92] mb-1 block">Target Audience</label>
                <Select name="targetRole" defaultValue="all">
                  <SelectTrigger className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#252529] border-[rgba(244,244,245,0.1)]">
                    <SelectItem value="all" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Everyone</SelectItem>
                    <SelectItem value="admin" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Admins</SelectItem>
                    <SelectItem value="teacher" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Teachers</SelectItem>
                    <SelectItem value="student" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Students</SelectItem>
                    <SelectItem value="parent" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Parents</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-[#8f8f92] mb-1 block">Priority</label>
                <Select name="priority" defaultValue="medium">
                  <SelectTrigger className="bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#252529] border-[rgba(244,244,245,0.1)]">
                    <SelectItem value="low" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Low</SelectItem>
                    <SelectItem value="medium" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Medium</SelectItem>
                    <SelectItem value="high" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">High</SelectItem>
                    <SelectItem value="urgent" className="text-[#f4f4f5] focus:bg-[#3a3a3e]">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => setShowAdd(false)} className="border-[rgba(244,244,245,0.15)] text-[#f4f4f5]">Cancel</Button>
              <Button type="submit" className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d]" disabled={createMutation.isPending}>Post</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
