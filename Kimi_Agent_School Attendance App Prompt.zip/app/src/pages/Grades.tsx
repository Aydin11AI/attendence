import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Award, Save, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function Grades() {
  const [selectedAssessment, setSelectedAssessment] = useState<string>("");
  const [gradeInputs, setGradeInputs] = useState<Record<number, { marks: string; comment: string }>>({});
  const [showReportCard, setShowReportCard] = useState(false);
  const [reportStudent, setReportStudent] = useState<any>(null);

  const { data: assessmentsData } = trpc.assessment.list.useQuery({});
  const { data: gradesData, isLoading } = trpc.grade.getByAssessment.useQuery(
    { assessmentId: Number(selectedAssessment) },
    { enabled: !!selectedAssessment }
  );

  const bulkEnterMutation = trpc.grade.bulkEnter.useMutation({
    onSuccess: () => { toast.success("Grades saved!"); setGradeInputs({}); },
    onError: (err) => toast.error(err.message),
  });

  const setGrade = (studentId: number, field: "marks" | "comment", value: string) => {
    setGradeInputs((prev) => ({
      ...prev,
      [studentId]: { ...prev[studentId], [field]: value },
    }));
  };

  const handleSave = () => {
    if (!selectedAssessment) return;
    const grades = Object.entries(gradeInputs)
      .filter(([, v]) => v.marks !== "")
      .map(([studentId, v]) => ({
        studentId: Number(studentId),
        marksObtained: Number(v.marks),
        teacherComments: v.comment || undefined,
      }));
    if (grades.length === 0) { toast.error("No grades to save"); return; }
    bulkEnterMutation.mutate({ assessmentId: Number(selectedAssessment), grades });
  };

  const getGradeColor = (grade?: string | null) => {
    if (!grade) return "#8f8f92";
    if (grade.startsWith("A")) return "#c8ff2d";
    if (grade.startsWith("B")) return "#2d8fff";
    if (grade.startsWith("C")) return "#ffae2d";
    return "#ff4d4d";
  };

  const selectedAssessmentInfo = assessmentsData?.find((a) => a.id.toString() === selectedAssessment);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-light tracking-tight text-[#f4f4f5] font-space">Grades</h1>
        <p className="text-sm text-[#8f8f92] mt-1">Enter and manage student grades</p>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center">
        <Select value={selectedAssessment} onValueChange={setSelectedAssessment}>
          <SelectTrigger className="w-72 bg-[#252529] border-[rgba(244,244,245,0.08)] text-[#f4f4f5]">
            <SelectValue placeholder="Select Assessment" />
          </SelectTrigger>
          <SelectContent className="bg-[#252529] border-[rgba(244,244,245,0.1)]">
            {(assessmentsData ?? []).map((a) => (
              <SelectItem key={a.id} value={a.id.toString()} className="text-[#f4f4f5] focus:bg-[#3a3a3e]">
                {a.name} — {a.subject.name} ({a.type})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedAssessmentInfo && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#252529] border border-[rgba(244,244,245,0.08)] text-xs text-[#8f8f92]">
            <Award className="w-3.5 h-3.5 text-[#c8ff2d]" />
            Total Marks: <span className="text-[#f4f4f5] font-medium">{selectedAssessmentInfo.totalMarks}</span>
            | Weight: <span className="text-[#f4f4f5] font-medium">{selectedAssessmentInfo.weight}x</span>
          </div>
        )}
        {Object.keys(gradeInputs).length > 0 && (
          <Button onClick={handleSave} className="bg-[#c8ff2d] text-[#1a1a1e] hover:bg-[#b8ef1d] font-medium gap-2 ml-auto" disabled={bulkEnterMutation.isPending}>
            <Save className="w-4 h-4" /> Save ({Object.keys(gradeInputs).length})
          </Button>
        )}
      </div>

      {/* Grade Entry Table */}
      {selectedAssessment ? (
        <div className="bg-[#252529] rounded-xl border border-[rgba(244,244,245,0.08)] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[rgba(244,244,245,0.08)]">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Student</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Roll #</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Marks</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Comment</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Current Grade</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">%</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-[#8f8f92] uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-10 bg-[#3a3a3e]" /></td></tr>
                  ))
                ) : (
                  (gradesData ?? []).map((g) => {
                    const input = gradeInputs[g.studentId];
                    const hasChange = input?.marks !== undefined && input.marks !== "";
                    return (
                      <tr key={g.studentId} className={`border-b border-[rgba(244,244,245,0.05)] ${hasChange ? "bg-[rgba(200,255,45,0.03)]" : "hover:bg-[rgba(255,255,255,0.02)]"} transition-colors`}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#2d8fff] to-[#c8ff2d] flex items-center justify-center text-[10px] font-bold text-[#1a1a1e]">
                              {g.studentName?.split(" ").map((n: string) => n[0]).join("")}
                            </div>
                            <span className="text-sm text-[#f4f4f5]">{g.studentName}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-[#8f8f92] font-mono">{g.rollNumber ?? "—"}</td>
                        <td className="px-4 py-3">
                          <Input
                            type="number"
                            min={0}
                            max={selectedAssessmentInfo?.totalMarks ?? 100}
                            value={input?.marks ?? (g.marksObtained || "")}
                            onChange={(e) => setGrade(g.studentId, "marks", e.target.value)}
                            className="w-20 h-8 text-sm bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5]"
                          />
                        </td>
                        <td className="px-4 py-3">
                          <Input
                            value={input?.comment ?? (g.teacherComments || "")}
                            onChange={(e) => setGrade(g.studentId, "comment", e.target.value)}
                            placeholder="Add comment..."
                            className="w-40 h-8 text-sm bg-[#1a1a1e] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] placeholder:text-[#8f8f92]"
                          />
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className="text-sm font-semibold font-space" style={{ color: getGradeColor(g.grade) }}>
                            {g.grade ?? "—"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center text-sm text-[#8f8f92]">{g.percentage ? `${g.percentage}%` : "—"}</td>
                        <td className="px-4 py-3 text-center">
                          <button
                            onClick={() => { setReportStudent(g); setShowReportCard(true); }}
                            className="p-1.5 rounded-lg text-[#8f8f92] hover:text-[#2d8fff] hover:bg-[rgba(45,143,255,0.1)] transition-colors"
                          >
                            <FileText className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-[#8f8f92]">
          <Award className="w-12 h-12 mb-3 opacity-40" />
          <p className="text-sm">Select an assessment to view and enter grades</p>
        </div>
      )}

      {/* Report Card Dialog */}
      <Dialog open={showReportCard} onOpenChange={setShowReportCard}>
        <DialogContent className="bg-[#252529] border-[rgba(244,244,245,0.1)] text-[#f4f4f5] max-w-md">
          <DialogHeader><DialogTitle className="font-space">Quick Grade Info</DialogTitle></DialogHeader>
          {reportStudent && (
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#2d8fff] to-[#c8ff2d] flex items-center justify-center text-sm font-bold text-[#1a1a1e]">
                  {reportStudent.studentName?.split(" ").map((n: string) => n[0]).join("")}
                </div>
                <div>
                  <p className="font-medium text-[#f4f4f5]">{reportStudent.studentName}</p>
                  <p className="text-xs text-[#8f8f92]">Roll: {reportStudent.rollNumber}</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-[#1a1a1e] rounded-lg p-3">
                  <p className="text-xs text-[#8f8f92]">Marks</p>
                  <p className="text-lg font-semibold font-space text-[#f4f4f5]">{reportStudent.marksObtained}</p>
                </div>
                <div className="bg-[#1a1a1e] rounded-lg p-3">
                  <p className="text-xs text-[#8f8f92]">Percentage</p>
                  <p className="text-lg font-semibold font-space text-[#2d8fff]">{reportStudent.percentage}%</p>
                </div>
                <div className="bg-[#1a1a1e] rounded-lg p-3">
                  <p className="text-xs text-[#8f8f92]">Grade</p>
                  <p className="text-lg font-semibold font-space" style={{ color: getGradeColor(reportStudent.grade) }}>{reportStudent.grade}</p>
                </div>
              </div>
              {reportStudent.teacherComments && (
                <div className="bg-[#1a1a1e] rounded-lg p-3">
                  <p className="text-xs text-[#8f8f92] mb-1">Teacher Comment</p>
                  <p className="text-sm text-[#f4f4f5]">{reportStudent.teacherComments}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
