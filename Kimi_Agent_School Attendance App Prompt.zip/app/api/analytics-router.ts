import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { students, attendanceRecords, grades, assessments, classes, subjects, teachers, users } from "@db/schema";
import { sql, eq, and, gte, count, avg } from "drizzle-orm";

export const analyticsRouter = createRouter({
  dashboard: publicQuery.query(async () => {
    const db = getDb();

    const totalStudentsResult = await db.select({ count: count() }).from(students);
    const totalTeachersResult = await db.select({ count: count() }).from(teachers);
    const totalClassesResult = await db.select({ count: count() }).from(classes);
    const totalSubjectsResult = await db.select({ count: count() }).from(subjects);

    // Average GPA calculation
    const avgGpaResult = await db.select({ avg: avg(grades.gpaPoints) }).from(grades);

    // Today's attendance
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayAttendance = await db
      .select({
        total: count(),
        present: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 ELSE 0 END)`,
      })
      .from(attendanceRecords)
      .where(eq(attendanceRecords.date, today));

    const totalToday = todayAttendance[0]?.total ?? 0;
    const presentToday = todayAttendance[0]?.present ?? 0;
    const attendanceRate = totalToday > 0 ? Math.round((presentToday / totalToday) * 100) : 0;

    // Students at risk (GPA < 2.0)
    const studentsAtRiskResult = await db
      .select({
        studentId: grades.studentId,
        avgGpa: sql<number>`AVG(${grades.gpaPoints})`,
      })
      .from(grades)
      .groupBy(grades.studentId)
      .having(sql`AVG(${grades.gpaPoints}) < 2.0`);

    return {
      totalStudents: totalStudentsResult[0]?.count ?? 0,
      totalTeachers: totalTeachersResult[0]?.count ?? 0,
      totalClasses: totalClassesResult[0]?.count ?? 0,
      totalSubjects: totalSubjectsResult[0]?.count ?? 0,
      avgGPA: avgGpaResult[0]?.avg ? parseFloat(avgGpaResult[0].avg).toFixed(2) : "0.00",
      todayAttendanceRate: attendanceRate,
      studentsAtRisk: studentsAtRiskResult.length,
    };
  }),

  attendanceTrend: publicQuery
    .input(
      z.object({
        period: z.enum(["week", "month", "semester"]).default("week"),
        classId: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const days = input.period === "week" ? 7 : input.period === "month" ? 30 : 120;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      startDate.setHours(0, 0, 0, 0);

      const conditions = [gte(attendanceRecords.date, startDate)];
      if (input.classId) {
        conditions.push(eq(attendanceRecords.classId, input.classId));
      }

      const results = await db
        .select({
          date: attendanceRecords.date,
          total: count(),
          present: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 ELSE 0 END)`,
        })
        .from(attendanceRecords)
        .where(and(...conditions))
        .groupBy(attendanceRecords.date)
        .orderBy(attendanceRecords.date);

      return results.map((r) => ({
        date: r.date,
        rate: r.total > 0 ? Math.round((r.present / r.total) * 100) : 0,
        total: r.total,
        present: r.present,
      }));
    }),

  gradeDistribution: publicQuery
    .input(
      z.object({
        classId: z.number().optional(),
        subjectId: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [];
      if (input.classId) {
        conditions.push(eq(assessments.classId, input.classId));
      }
      if (input.subjectId) {
        conditions.push(eq(assessments.subjectId, input.subjectId));
      }

      const results = await db
        .select({
          grade: grades.grade,
          count: count(),
        })
        .from(grades)
        .innerJoin(assessments, eq(grades.assessmentId, assessments.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .groupBy(grades.grade);

      const distribution: Record<string, number> = { "A+": 0, A: 0, "B+": 0, B: 0, "C+": 0, C: 0, D: 0, F: 0 };
      for (const r of results) {
        if (r.grade) distribution[r.grade] = r.count;
      }
      return distribution;
    }),

  topPerformers: publicQuery
    .input(
      z.object({
        limit: z.number().default(10),
        classId: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [];
      if (input.classId) {
        conditions.push(eq(students.classId, input.classId));
      }

      const results = await db
        .select({
          studentId: grades.studentId,
          avgGpa: sql<number>`AVG(${grades.gpaPoints})`,
          avgPercentage: sql<number>`AVG(${grades.percentage})`,
        })
        .from(grades)
        .innerJoin(students, eq(grades.studentId, students.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .groupBy(grades.studentId)
        .orderBy(sql`AVG(${grades.gpaPoints}) DESC`)
        .limit(input.limit);

      // Get student details
      const enriched = await Promise.all(
        results.filter((r) => r.studentId !== null).map(async (r) => {
          const student = await db
            .select()
            .from(students)
            .innerJoin(users, eq(students.userId, users.id))
            .innerJoin(classes, eq(students.classId, classes.id))
            .where(eq(students.id, r.studentId as number))
            .limit(1);

          return {
            studentId: r.studentId,
            avgGpa: parseFloat(r.avgGpa.toFixed(2)),
            avgPercentage: parseFloat(r.avgPercentage.toFixed(1)),
            name: student[0]?.users.name ?? "Unknown",
            studentCode: student[0]?.students.studentId ?? "",
            className: student[0]?.classes.name ?? "",
          };
        })
      );

      return enriched;
    }),

  classPerformance: publicQuery.query(async () => {
    const db = getDb();

    const allClasses = await db.select().from(classes).where(eq(classes.status, "active"));

    const performance = await Promise.all(
      allClasses.map(async (cls) => {
        // Get avg attendance for this class
        const last30Days = new Date();
        last30Days.setDate(last30Days.getDate() - 30);
        last30Days.setHours(0, 0, 0, 0);

        const attendanceResult = await db
          .select({
            total: count(),
            present: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 ELSE 0 END)`,
          })
          .from(attendanceRecords)
          .where(and(eq(attendanceRecords.classId, cls.id), gte(attendanceRecords.date, last30Days)));

        const avgAttendance =
          (attendanceResult[0]?.total ?? 0) > 0
            ? Math.round(((attendanceResult[0]?.present ?? 0) / (attendanceResult[0]?.total ?? 1)) * 100)
            : 0;

        // Get avg GPA for students in this class
        const gpaResult = await db
          .select({ avg: avg(grades.gpaPoints) })
          .from(grades)
          .innerJoin(students, eq(grades.studentId, students.id))
          .where(eq(students.classId, cls.id));

        const avgGPA = gpaResult[0]?.avg ? parseFloat(parseFloat(gpaResult[0].avg).toFixed(2)) : 0;

        // Get student count
        const studentCount = await db
          .select({ count: count() })
          .from(students)
          .where(eq(students.classId, cls.id));

        return {
          classId: cls.id,
          className: cls.name,
          gradeLevel: cls.gradeLevel,
          section: cls.section,
          studentCount: studentCount[0]?.count ?? 0,
          avgAttendance,
          avgGPA,
        };
      })
    );

    return performance;
  }),
});
