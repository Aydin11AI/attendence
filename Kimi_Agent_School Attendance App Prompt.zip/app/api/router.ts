import { authRouter } from "./auth-router";
import { analyticsRouter } from "./analytics-router";
import { studentRouter } from "./student-router";
import { attendanceRouter } from "./attendance-router";
import { gradeRouter } from "./grade-router";
import { assessmentRouter } from "./assessment-router";
import { teacherRouter } from "./teacher-router";
import { classSubjectRouter } from "./class-subject-router";
import { announcementRouter } from "./announcement-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  analytics: analyticsRouter,
  student: studentRouter,
  attendance: attendanceRouter,
  grade: gradeRouter,
  assessment: assessmentRouter,
  teacher: teacherRouter,
  classSubject: classSubjectRouter,
  announcement: announcementRouter,
});

export type AppRouter = typeof appRouter;
