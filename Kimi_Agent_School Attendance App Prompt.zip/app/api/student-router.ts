import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { students, users, classes, grades, attendanceRecords } from "@db/schema";
import { eq, like, and, sql, count, desc } from "drizzle-orm";

export const studentRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        classId: z.number().optional(),
        status: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const offset = (input.page - 1) * input.limit;

      const conditions: any[] = [];
      if (input.search) {
        conditions.push(like(users.name, `%${input.search}%`));
      }
      if (input.classId) {
        conditions.push(eq(students.classId, input.classId));
      }
      if (input.status) {
        conditions.push(sql`${students.status} = ${input.status}`);
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const results = await db
        .select()
        .from(students)
        .innerJoin(users, eq(students.userId, users.id))
        .innerJoin(classes, eq(students.classId, classes.id))
        .where(whereClause)
        .orderBy(users.name)
        .limit(input.limit)
        .offset(offset);

      const totalResult = await db
        .select({ count: count() })
        .from(students)
        .innerJoin(users, eq(students.userId, users.id))
        .where(whereClause);

      return {
        students: results.map((r) => ({
          id: r.students.id,
          name: r.users.name,
          email: r.users.email,
          avatar: r.users.avatar,
          studentId: r.students.studentId,
          rollNumber: r.students.rollNumber,
          className: r.classes.name,
          classId: r.classes.id,
          gradeLevel: r.classes.gradeLevel,
          gender: r.students.gender,
          dateOfBirth: r.students.dateOfBirth,
          parentName: r.students.parentName,
          parentPhone: r.students.parentPhone,
          status: r.students.status,
          createdAt: r.students.createdAt,
        })),
        total: totalResult[0]?.count ?? 0,
        page: input.page,
        totalPages: Math.ceil((totalResult[0]?.count ?? 0) / input.limit),
      };
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();

      const student = await db
        .select()
        .from(students)
        .innerJoin(users, eq(students.userId, users.id))
        .innerJoin(classes, eq(students.classId, classes.id))
        .where(eq(students.id, input.id))
        .limit(1);

      if (!student[0]) return null;

      // Get attendance stats
      const attendanceStats = await db
        .select({
          total: count(),
          present: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 ELSE 0 END)`,
          absent: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'absent' THEN 1 ELSE 0 END)`,
          late: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'late' THEN 1 ELSE 0 END)`,
        })
        .from(attendanceRecords)
        .where(eq(attendanceRecords.studentId, input.id));

      // Get recent grades
      const recentGrades = await db
        .select()
        .from(grades)
        .where(eq(grades.studentId, input.id))
        .orderBy(desc(grades.gradedAt))
        .limit(10);

      return {
        ...student[0],
        attendanceStats: attendanceStats[0] ?? { total: 0, present: 0, absent: 0, late: 0 },
        recentGrades,
      };
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email(),
        studentId: z.string().min(1),
        classId: z.number(),
        rollNumber: z.number().optional(),
        dateOfBirth: z.string().optional(),
        gender: z.enum(["male", "female", "other"]).optional(),
        parentName: z.string().optional(),
        parentPhone: z.string().optional(),
        parentEmail: z.string().email().optional(),
        address: z.string().optional(),
        emergencyContact: z.string().optional(),
        bloodGroup: z.string().optional(),
        admissionDate: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Create user first
      const [user] = await db.insert(users).values({
        unionId: `student_${input.studentId}_${Date.now()}`,
        name: input.name,
        email: input.email,
        role: "student",
        status: "active",
      });

      const userId = Number(user.insertId);

      // Create student record
      const [student] = await db.insert(students).values({
        userId,
        studentId: input.studentId,
        classId: input.classId,
        rollNumber: input.rollNumber ?? null,
        dateOfBirth: input.dateOfBirth ? new Date(input.dateOfBirth) : null,
        gender: input.gender ?? null,
        parentName: input.parentName ?? null,
        parentPhone: input.parentPhone ?? null,
        parentEmail: input.parentEmail ?? null,
        address: input.address ?? null,
        emergencyContact: input.emergencyContact ?? null,
        bloodGroup: input.bloodGroup ?? null,
        admissionDate: input.admissionDate ? new Date(input.admissionDate) : null,
      });

      return { userId, studentId: Number(student.insertId) };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().email().optional(),
        classId: z.number().optional(),
        rollNumber: z.number().optional(),
        dateOfBirth: z.string().optional(),
        gender: z.enum(["male", "female", "other"]).optional(),
        parentName: z.string().optional(),
        parentPhone: z.string().optional(),
        parentEmail: z.string().email().optional(),
        address: z.string().optional(),
        emergencyContact: z.string().optional(),
        bloodGroup: z.string().optional(),
        status: z.enum(["active", "inactive", "graduated", "transferred"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;

      // Get student to find userId
      const student = await db.select().from(students).where(eq(students.id, id)).limit(1);
      if (!student[0]) throw new Error("Student not found");

      const userId = student[0].userId;
      if (!userId) throw new Error("Student has no associated user");

      // Update user
      if (data.name || data.email) {
        await db
          .update(users)
          .set({
            ...(data.name && { name: data.name }),
            ...(data.email && { email: data.email }),
          })
          .where(eq(users.id, userId));
      }

      // Update student
      await db
        .update(students)
        .set({
          ...(data.classId && { classId: data.classId }),
          ...(data.rollNumber && { rollNumber: data.rollNumber }),
          ...(data.dateOfBirth && { dateOfBirth: new Date(data.dateOfBirth) }),
          ...(data.gender && { gender: data.gender }),
          ...(data.parentName && { parentName: data.parentName }),
          ...(data.parentPhone && { parentPhone: data.parentPhone }),
          ...(data.parentEmail && { parentEmail: data.parentEmail }),
          ...(data.address && { address: data.address }),
          ...(data.emergencyContact && { emergencyContact: data.emergencyContact }),
          ...(data.bloodGroup && { bloodGroup: data.bloodGroup }),
          ...(data.status && { status: data.status }),
        })
        .where(eq(students.id, id));

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const student = await db.select().from(students).where(eq(students.id, input.id)).limit(1);
      if (!student[0]) throw new Error("Student not found");

      const userId = student[0].userId;

      await db.delete(students).where(eq(students.id, input.id));
      if (userId) {
        await db.delete(users).where(eq(users.id, userId));
      }

      return { success: true };
    }),
});
