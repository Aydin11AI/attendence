import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { assessments, subjects, classes, teachers, users } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export const assessmentRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        classId: z.number().optional(),
        subjectId: z.number().optional(),
        type: z.string().optional(),
        academicYear: z.string().optional(),
        semester: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [];
      if (input.classId) conditions.push(eq(assessments.classId, input.classId));
      if (input.subjectId) conditions.push(eq(assessments.subjectId, input.subjectId));
      if (input.type) conditions.push(eq(assessments.type, input.type as any));
      if (input.academicYear) conditions.push(eq(assessments.academicYear, input.academicYear));
      if (input.semester) conditions.push(eq(assessments.semester, input.semester as any));

      const results = await db
        .select()
        .from(assessments)
        .innerJoin(subjects, eq(assessments.subjectId, subjects.id))
        .innerJoin(classes, eq(assessments.classId, classes.id))
        .innerJoin(teachers, eq(assessments.teacherId, teachers.id))
        .innerJoin(users, eq(teachers.userId, users.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(assessments.createdAt));

      return results.map((r) => ({
        id: r.assessments.id,
        name: r.assessments.name,
        type: r.assessments.type,
        totalMarks: r.assessments.totalMarks,
        weight: r.assessments.weight ? parseFloat(r.assessments.weight.toString()) : 1,
        dueDate: r.assessments.dueDate,
        academicYear: r.assessments.academicYear,
        semester: r.assessments.semester,
        status: r.assessments.status,
        subject: { id: r.subjects.id, name: r.subjects.name, code: r.subjects.code },
        class: { id: r.classes.id, name: r.classes.name },
        teacher: { id: r.teachers.id, name: r.users.name },
      }));
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        subjectId: z.number(),
        classId: z.number(),
        teacherId: z.number(),
        type: z.enum(["quiz", "assignment", "midterm", "final", "project"]),
        totalMarks: z.number().min(1),
        weight: z.number().default(1),
        dueDate: z.string().optional(),
        academicYear: z.string(),
        semester: z.enum(["fall", "spring", "summer"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const [result] = await db.insert(assessments).values({
        name: input.name,
        subjectId: input.subjectId,
        classId: input.classId,
        teacherId: input.teacherId,
        type: input.type,
        totalMarks: input.totalMarks,
        weight: input.weight.toString(),
        dueDate: input.dueDate ? new Date(input.dueDate) : null,
        academicYear: input.academicYear,
        semester: input.semester,
      });

      return { id: result.insertId };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        totalMarks: z.number().optional(),
        weight: z.number().optional(),
        dueDate: z.string().optional(),
        status: z.enum(["active", "completed", "cancelled"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;

      await db
        .update(assessments)
        .set({
          ...(data.name && { name: data.name }),
          ...(data.totalMarks && { totalMarks: data.totalMarks }),
          ...(data.weight && { weight: data.weight.toString() }),
          ...(data.dueDate && { dueDate: new Date(data.dueDate) }),
          ...(data.status && { status: data.status }),
        })
        .where(eq(assessments.id, id));

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(assessments).where(eq(assessments.id, input.id));
      return { success: true };
    }),
});
