import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { classes, subjects, schools } from "@db/schema";
import { eq, and, sql } from "drizzle-orm";

export const classSubjectRouter = createRouter({
  // ─── Classes ──────────────────────────────────────────────
  listClasses: publicQuery
    .input(
      z.object({
        schoolId: z.number().optional(),
        gradeLevel: z.number().optional(),
        academicYear: z.string().optional(),
        status: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [];
      if (input.schoolId) conditions.push(eq(classes.schoolId, input.schoolId));
      if (input.gradeLevel) conditions.push(eq(classes.gradeLevel, input.gradeLevel));
      if (input.academicYear) conditions.push(eq(classes.academicYear, input.academicYear));
      if (input.status) {
        conditions.push(sql`${classes.status} = ${input.status}`);
      }

      const results = await db
        .select()
        .from(classes)
        .leftJoin(schools, eq(classes.schoolId, schools.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(classes.gradeLevel, classes.section);

      return results.map((r) => ({
        id: r.classes.id,
        name: r.classes.name,
        gradeLevel: r.classes.gradeLevel,
        section: r.classes.section,
        academicYear: r.classes.academicYear,
        roomNumber: r.classes.roomNumber,
        status: r.classes.status,
        schoolName: r.schools?.name ?? "",
      }));
    }),

  createClass: publicQuery
    .input(
      z.object({
        schoolId: z.number(),
        name: z.string().min(1),
        gradeLevel: z.number().min(1).max(12),
        section: z.string().optional(),
        academicYear: z.string(),
        roomNumber: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(classes).values({
        schoolId: input.schoolId,
        name: input.name,
        gradeLevel: input.gradeLevel,
        section: input.section ?? null,
        academicYear: input.academicYear,
        roomNumber: input.roomNumber ?? null,
      });
      return { id: Number(result.insertId) };
    }),

  updateClass: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        gradeLevel: z.number().optional(),
        section: z.string().optional(),
        roomNumber: z.string().optional(),
        status: z.enum(["active", "inactive"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db
        .update(classes)
        .set({
          ...(data.name && { name: data.name }),
          ...(data.gradeLevel && { gradeLevel: data.gradeLevel }),
          ...(data.section !== undefined && { section: data.section || null }),
          ...(data.roomNumber !== undefined && { roomNumber: data.roomNumber || null }),
          ...(data.status && { status: data.status }),
        })
        .where(eq(classes.id, id));
      return { success: true };
    }),

  deleteClass: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(classes).where(eq(classes.id, input.id));
      return { success: true };
    }),

  // ─── Subjects ─────────────────────────────────────────────
  listSubjects: publicQuery
    .input(
      z.object({
        schoolId: z.number().optional(),
        status: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [];
      if (input.schoolId) conditions.push(eq(subjects.schoolId, input.schoolId));
      if (input.status) {
        conditions.push(sql`${subjects.status} = ${input.status}`);
      }

      const results = await db
        .select()
        .from(subjects)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(subjects.name);

      return results.map((r) => ({
        id: r.id,
        name: r.name,
        code: r.code,
        description: r.description,
        credits: r.credits,
        status: r.status,
      }));
    }),

  createSubject: publicQuery
    .input(
      z.object({
        schoolId: z.number(),
        name: z.string().min(1),
        code: z.string().min(1),
        description: z.string().optional(),
        credits: z.number().default(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(subjects).values({
        schoolId: input.schoolId,
        name: input.name,
        code: input.code,
        description: input.description ?? null,
        credits: input.credits,
      });
      return { id: Number(result.insertId) };
    }),

  updateSubject: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        code: z.string().optional(),
        description: z.string().optional(),
        credits: z.number().optional(),
        status: z.enum(["active", "inactive"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db
        .update(subjects)
        .set({
          ...(data.name && { name: data.name }),
          ...(data.code && { code: data.code }),
          ...(data.description !== undefined && { description: data.description || null }),
          ...(data.credits && { credits: data.credits }),
          ...(data.status && { status: data.status }),
        })
        .where(eq(subjects.id, id));
      return { success: true };
    }),

  deleteSubject: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(subjects).where(eq(subjects.id, input.id));
      return { success: true };
    }),
});
