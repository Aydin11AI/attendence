import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { teachers, users, teacherClasses, classes, subjects } from "@db/schema";
import { eq, like, and, count } from "drizzle-orm";

export const teacherRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        specialization: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const offset = (input.page - 1) * input.limit;

      const conditions: any[] = [];
      if (input.search) {
        conditions.push(like(users.name, `%${input.search}%`));
      }
      if (input.specialization) {
        conditions.push(eq(teachers.specialization, input.specialization));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const results = await db
        .select()
        .from(teachers)
        .innerJoin(users, eq(teachers.userId, users.id))
        .where(whereClause)
        .limit(input.limit)
        .offset(offset);

      const totalResult = await db
        .select({ count: count() })
        .from(teachers)
        .innerJoin(users, eq(teachers.userId, users.id))
        .where(whereClause);

      return {
        teachers: results.map((r) => ({
          id: r.teachers.id,
          name: r.users.name,
          email: r.users.email,
          avatar: r.users.avatar,
          employeeId: r.teachers.employeeId,
          qualification: r.teachers.qualification,
          specialization: r.teachers.specialization,
          joinDate: r.teachers.joinDate,
          phone: r.teachers.phone,
          status: r.teachers.status,
        })),
        total: totalResult[0]?.count ?? 0,
        page: input.page,
        totalPages: Math.ceil((totalResult[0]?.count ?? 0) / input.limit),
      };
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();

      const teacher = await db
        .select()
        .from(teachers)
        .innerJoin(users, eq(teachers.userId, users.id))
        .where(eq(teachers.id, input.id))
        .limit(1);

      if (!teacher[0]) return null;

      // Get class assignments
      const assignments = await db
        .select()
        .from(teacherClasses)
        .innerJoin(classes, eq(teacherClasses.classId, classes.id))
        .innerJoin(subjects, eq(teacherClasses.subjectId, subjects.id))
        .where(eq(teacherClasses.teacherId, input.id));

      return {
        ...teacher[0],
        assignments: assignments.map((a) => ({
          id: a.teacher_classes.id,
          className: a.classes.name,
          subjectName: a.subjects.name,
          academicYear: a.teacher_classes.academicYear,
        })),
      };
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email(),
        employeeId: z.string().min(1),
        qualification: z.string().optional(),
        specialization: z.string().optional(),
        joinDate: z.string().optional(),
        phone: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const [user] = await db.insert(users).values({
        unionId: `teacher_${input.employeeId}_${Date.now()}`,
        name: input.name,
        email: input.email,
        role: "teacher",
        status: "active",
      });

      const userId = Number(user.insertId);

      const [teacher] = await db.insert(teachers).values({
        userId,
        employeeId: input.employeeId,
        qualification: input.qualification ?? null,
        specialization: input.specialization ?? null,
        joinDate: input.joinDate ? new Date(input.joinDate) : null,
        phone: input.phone ?? null,
      });

      return { userId, teacherId: Number(teacher.insertId) };
    }),

  assignClass: publicQuery
    .input(
      z.object({
        teacherId: z.number(),
        classId: z.number(),
        subjectId: z.number(),
        academicYear: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const [result] = await db.insert(teacherClasses).values({
        teacherId: input.teacherId,
        classId: input.classId,
        subjectId: input.subjectId,
        academicYear: input.academicYear,
      });

      return { id: Number(result.insertId) };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const teacher = await db.select().from(teachers).where(eq(teachers.id, input.id)).limit(1);
      if (!teacher[0]) throw new Error("Teacher not found");

      const userId = teacher[0].userId;

      await db.delete(teacherClasses).where(eq(teacherClasses.teacherId, input.id));
      await db.delete(teachers).where(eq(teachers.id, input.id));
      if (userId) {
        await db.delete(users).where(eq(users.id, userId));
      }

      return { success: true };
    }),
});
