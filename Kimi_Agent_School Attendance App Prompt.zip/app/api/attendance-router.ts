import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { attendanceRecords, students, users, classes } from "@db/schema";
import { eq, and, gte, lte, desc, count, sql } from "drizzle-orm";

export const attendanceRouter = createRouter({
  getByDate: publicQuery
    .input(
      z.object({
        date: z.string(),
        classId: z.number(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const queryDate = new Date(input.date);
      queryDate.setHours(0, 0, 0, 0);

      // Get all students in the class with their attendance for the date
      const studentsInClass = await db
        .select()
        .from(students)
        .innerJoin(users, eq(students.userId, users.id))
        .where(eq(students.classId, input.classId));

      const attendanceForDate = await db
        .select()
        .from(attendanceRecords)
        .where(
          and(
            eq(attendanceRecords.date, queryDate),
            eq(attendanceRecords.classId, input.classId)
          )
        );

      const attendanceMap = new Map(
        attendanceForDate.map((a) => [a.studentId, a])
      );

      return studentsInClass.map((s) => {
        const record = attendanceMap.get(s.students.id);
        return {
          studentId: s.students.id,
          studentName: s.users.name,
          rollNumber: s.students.rollNumber,
          status: record?.status ?? "unmarked",
          notes: record?.notes ?? "",
          recordId: record?.id ?? null,
        };
      });
    }),

  mark: publicQuery
    .input(
      z.object({
        studentId: z.number(),
        classId: z.number(),
        teacherId: z.number(),
        date: z.string(),
        status: z.enum(["present", "absent", "late", "excused"]),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const queryDate = new Date(input.date);
      queryDate.setHours(0, 0, 0, 0);

      // Check if record exists
      const existing = await db
        .select()
        .from(attendanceRecords)
        .where(
          and(
            eq(attendanceRecords.studentId, input.studentId),
            eq(attendanceRecords.date, queryDate)
          )
        )
        .limit(1);

      if (existing[0]) {
        await db
          .update(attendanceRecords)
          .set({
            status: input.status,
            notes: input.notes ?? null,
            teacherId: input.teacherId,
          })
          .where(eq(attendanceRecords.id, existing[0].id));
        return { id: existing[0].id, updated: true };
      } else {
        const [record] = await db.insert(attendanceRecords).values({
          studentId: input.studentId,
          classId: input.classId,
          teacherId: input.teacherId,
          date: queryDate,
          status: input.status,
          notes: input.notes ?? null,
        });
        return { id: record.insertId, updated: false };
      }
    }),

  bulkMark: publicQuery
    .input(
      z.object({
        classId: z.number(),
        teacherId: z.number(),
        date: z.string(),
        records: z.array(
          z.object({
            studentId: z.number(),
            status: z.enum(["present", "absent", "late", "excused"]),
            notes: z.string().optional(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const queryDate = new Date(input.date);
      queryDate.setHours(0, 0, 0, 0);

      for (const record of input.records) {
        const existing = await db
          .select()
          .from(attendanceRecords)
          .where(
            and(
              eq(attendanceRecords.studentId, record.studentId),
              eq(attendanceRecords.date, queryDate)
            )
          )
          .limit(1);

        if (existing[0]) {
          await db
            .update(attendanceRecords)
            .set({
              status: record.status,
              notes: record.notes ?? null,
              teacherId: input.teacherId,
            })
            .where(eq(attendanceRecords.id, existing[0].id));
        } else {
          await db.insert(attendanceRecords).values({
            studentId: record.studentId,
            classId: input.classId,
            teacherId: input.teacherId,
            date: queryDate,
            status: record.status,
            notes: record.notes ?? null,
          });
        }
      }

      return { success: true, count: input.records.length };
    }),

  getHistory: publicQuery
    .input(
      z.object({
        studentId: z.number(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [eq(attendanceRecords.studentId, input.studentId)];
      if (input.startDate) {
        const sd = new Date(input.startDate);
        sd.setHours(0, 0, 0, 0);
        conditions.push(gte(attendanceRecords.date, sd));
      }
      if (input.endDate) {
        const ed = new Date(input.endDate);
        ed.setHours(0, 0, 0, 0);
        conditions.push(lte(attendanceRecords.date, ed));
      }

      const results = await db
        .select()
        .from(attendanceRecords)
        .innerJoin(students, eq(attendanceRecords.studentId, students.id))
        .innerJoin(users, eq(students.userId, users.id))
        .innerJoin(classes, eq(attendanceRecords.classId, classes.id))
        .where(and(...conditions))
        .orderBy(desc(attendanceRecords.date));

      return results.map((r) => ({
        id: r.attendance_records.id,
        date: r.attendance_records.date,
        status: r.attendance_records.status,
        notes: r.attendance_records.notes,
        studentName: r.users.name,
        className: r.classes.name,
      }));
    }),

  getStats: publicQuery
    .input(
      z.object({
        studentId: z.number().optional(),
        classId: z.number().optional(),
        period: z.enum(["week", "month", "semester", "year"]).default("month"),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const days =
        input.period === "week" ? 7 : input.period === "month" ? 30 : input.period === "semester" ? 120 : 365;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      startDate.setHours(0, 0, 0, 0);

      const conditions: any[] = [gte(attendanceRecords.date, startDate)];
      if (input.studentId) conditions.push(eq(attendanceRecords.studentId, input.studentId));
      if (input.classId) conditions.push(eq(attendanceRecords.classId, input.classId));

      const results = await db
        .select({
          total: count(),
          present: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 ELSE 0 END)`,
          absent: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'absent' THEN 1 ELSE 0 END)`,
          late: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'late' THEN 1 ELSE 0 END)`,
          excused: sql<number>`SUM(CASE WHEN ${attendanceRecords.status} = 'excused' THEN 1 ELSE 0 END)`,
        })
        .from(attendanceRecords)
        .where(and(...conditions));

      const stats = results[0] ?? { total: 0, present: 0, absent: 0, late: 0, excused: 0 };
      const total = stats.total ?? 0;

      return {
        ...stats,
        presentRate: total > 0 ? Math.round((stats.present / total) * 100) : 0,
        absentRate: total > 0 ? Math.round((stats.absent / total) * 100) : 0,
        lateRate: total > 0 ? Math.round((stats.late / total) * 100) : 0,
      };
    }),
});
