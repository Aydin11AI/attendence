import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { announcements, users, schools } from "@db/schema";
import { eq, and, desc, gte } from "drizzle-orm";

export const announcementRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        targetRole: z.string().optional(),
        priority: z.string().optional(),
        limit: z.number().default(20),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [];
      if (input.targetRole) {
        conditions.push(eq(announcements.targetRole, input.targetRole as any));
      }
      if (input.priority) {
        conditions.push(eq(announcements.priority, input.priority as any));
      }

      // Only show non-expired announcements
      const now = new Date();
      conditions.push(
        gte(announcements.expiresAt ?? announcements.createdAt, now)
      );

      const results = await db
        .select()
        .from(announcements)
        .innerJoin(users, eq(announcements.authorId, users.id))
        .leftJoin(schools, eq(announcements.schoolId, schools.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(announcements.createdAt))
        .limit(input.limit);

      return results.map((r) => ({
        id: r.announcements.id,
        title: r.announcements.title,
        content: r.announcements.content,
        priority: r.announcements.priority,
        targetRole: r.announcements.targetRole,
        expiresAt: r.announcements.expiresAt,
        createdAt: r.announcements.createdAt,
        authorName: r.users.name,
        schoolName: r.schools?.name ?? null,
      }));
    }),

  create: publicQuery
    .input(
      z.object({
        title: z.string().min(1),
        content: z.string().min(1),
        schoolId: z.number().optional(),
        authorId: z.number(),
        targetRole: z.enum(["all", "admin", "teacher", "student", "parent"]).default("all"),
        priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
        expiresAt: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const [result] = await db.insert(announcements).values({
        title: input.title,
        content: input.content,
        schoolId: input.schoolId ?? null,
        authorId: input.authorId,
        targetRole: input.targetRole,
        priority: input.priority,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
      });

      return { id: result.insertId };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(announcements).where(eq(announcements.id, input.id));
      return { success: true };
    }),
});
