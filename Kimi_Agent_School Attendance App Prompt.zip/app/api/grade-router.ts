import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { grades, assessments, students, users, classes, subjects } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

function calculateGradeLetter(percentage: number): string {
  if (percentage >= 97) return "A+";
  if (percentage >= 93) return "A";
  if (percentage >= 90) return "A-";
  if (percentage >= 87) return "B+";
  if (percentage >= 83) return "B";
  if (percentage >= 80) return "B-";
  if (percentage >= 77) return "C+";
  if (percentage >= 73) return "C";
  if (percentage >= 70) return "C-";
  if (percentage >= 67) return "D+";
  if (percentage >= 63) return "D";
  if (percentage >= 60) return "D-";
  return "F";
}

function calculateGpaPoints(grade: string): number {
  const map: Record<string, number> = {
    "A+": 4.0, A: 4.0, "A-": 3.7,
    "B+": 3.3, B: 3.0, "B-": 2.7,
    "C+": 2.3, C: 2.0, "C-": 1.7,
    "D+": 1.3, D: 1.0, "D-": 0.7,
    F: 0.0,
  };
  return map[grade] ?? 0;
}

export const gradeRouter = createRouter({
  getByStudent: publicQuery
    .input(
      z.object({
        studentId: z.number(),
        semester: z.string().optional(),
        academicYear: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const conditions: any[] = [eq(grades.studentId, input.studentId)];

      const results = await db
        .select()
        .from(grades)
        .innerJoin(assessments, eq(grades.assessmentId, assessments.id))
        .innerJoin(subjects, eq(assessments.subjectId, subjects.id))
        .where(and(...conditions))
        .orderBy(desc(grades.gradedAt));

      return results.map((r) => ({
        id: r.grades.id,
        marksObtained: r.grades.marksObtained,
        percentage: r.grades.percentage ? parseFloat(r.grades.percentage.toString()) : 0,
        grade: r.grades.grade,
        gpaPoints: r.grades.gpaPoints ? parseFloat(r.grades.gpaPoints.toString()) : 0,
        teacherComments: r.grades.teacherComments,
        gradedAt: r.grades.gradedAt,
        assessment: {
          id: r.assessments.id,
          name: r.assessments.name,
          type: r.assessments.type,
          totalMarks: r.assessments.totalMarks,
          weight: r.assessments.weight ? parseFloat(r.assessments.weight.toString()) : 1,
          dueDate: r.assessments.dueDate,
          semester: r.assessments.semester,
        },
        subject: {
          id: r.subjects.id,
          name: r.subjects.name,
          code: r.subjects.code,
        },
      }));
    }),

  getByAssessment: publicQuery
    .input(z.object({ assessmentId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();

      const results = await db
        .select()
        .from(grades)
        .innerJoin(students, eq(grades.studentId, students.id))
        .innerJoin(users, eq(students.userId, users.id))
        .where(eq(grades.assessmentId, input.assessmentId));

      return results.map((r) => ({
        gradeId: r.grades.id,
        studentId: r.students.id,
        studentName: r.users.name,
        rollNumber: r.students.rollNumber,
        marksObtained: r.grades.marksObtained,
        percentage: r.grades.percentage ? parseFloat(r.grades.percentage.toString()) : 0,
        grade: r.grades.grade,
        teacherComments: r.grades.teacherComments,
      }));
    }),

  enter: publicQuery
    .input(
      z.object({
        studentId: z.number(),
        assessmentId: z.number(),
        marksObtained: z.number().min(0),
        teacherComments: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Get assessment total marks
      const assessment = await db
        .select()
        .from(assessments)
        .where(eq(assessments.id, input.assessmentId))
        .limit(1);

      if (!assessment[0]) throw new Error("Assessment not found");

      const totalMarks = assessment[0].totalMarks;
      const percentage = Math.min(100, Math.round((input.marksObtained / totalMarks) * 100 * 100) / 100);
      const gradeLetter = calculateGradeLetter(percentage);
      const gpaPoints = calculateGpaPoints(gradeLetter);

      // Check if grade exists
      const existing = await db
        .select()
        .from(grades)
        .where(
          and(
            eq(grades.studentId, input.studentId),
            eq(grades.assessmentId, input.assessmentId)
          )
        )
        .limit(1);

      if (existing[0]) {
        await db
          .update(grades)
          .set({
            marksObtained: input.marksObtained,
            percentage: percentage.toString(),
            grade: gradeLetter,
            gpaPoints: gpaPoints.toString(),
            teacherComments: input.teacherComments ?? null,
          })
          .where(eq(grades.id, existing[0].id));
        return { id: existing[0].id, grade: gradeLetter, percentage, gpaPoints };
      } else {
        const [result] = await db.insert(grades).values({
          studentId: input.studentId,
          assessmentId: input.assessmentId,
          marksObtained: input.marksObtained,
          percentage: percentage.toString(),
          grade: gradeLetter,
          gpaPoints: gpaPoints.toString(),
          teacherComments: input.teacherComments ?? null,
        });
        return { id: Number(result.insertId), grade: gradeLetter, percentage, gpaPoints };
      }
    }),

  bulkEnter: publicQuery
    .input(
      z.object({
        assessmentId: z.number(),
        grades: z.array(
          z.object({
            studentId: z.number(),
            marksObtained: z.number().min(0),
            teacherComments: z.string().optional(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const assessment = await db
        .select()
        .from(assessments)
        .where(eq(assessments.id, input.assessmentId))
        .limit(1);

      if (!assessment[0]) throw new Error("Assessment not found");
      const totalMarks = assessment[0].totalMarks;

      for (const g of input.grades) {
        const percentage = Math.min(100, Math.round((g.marksObtained / totalMarks) * 100 * 100) / 100);
        const gradeLetter = calculateGradeLetter(percentage);
        const gpaPoints = calculateGpaPoints(gradeLetter);

        const existing = await db
          .select()
          .from(grades)
          .where(
            and(
              eq(grades.studentId, g.studentId),
              eq(grades.assessmentId, input.assessmentId)
            )
          )
          .limit(1);

        if (existing[0]) {
          await db
            .update(grades)
            .set({
              marksObtained: g.marksObtained,
              percentage: percentage.toString(),
              grade: gradeLetter,
              gpaPoints: gpaPoints.toString(),
              teacherComments: g.teacherComments ?? null,
            })
            .where(eq(grades.id, existing[0].id));
        } else {
          await db.insert(grades).values({
            studentId: g.studentId,
            assessmentId: input.assessmentId,
            marksObtained: g.marksObtained,
            percentage: percentage.toString(),
            grade: gradeLetter,
            gpaPoints: gpaPoints.toString(),
            teacherComments: g.teacherComments ?? null,
          });
        }
      }

      return { success: true, count: input.grades.length };
    }),

  getReportCard: publicQuery
    .input(
      z.object({
        studentId: z.number(),
        semester: z.string(),
        academicYear: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const student = await db
        .select()
        .from(students)
        .innerJoin(users, eq(students.userId, users.id))
        .innerJoin(classes, eq(students.classId, classes.id))
        .where(eq(students.id, input.studentId))
        .limit(1);

      if (!student[0]) return null;

      // Get all grades for the semester
      const results = await db
        .select()
        .from(grades)
        .innerJoin(assessments, eq(grades.assessmentId, assessments.id))
        .innerJoin(subjects, eq(assessments.subjectId, subjects.id))
        .where(
          and(
            eq(grades.studentId, input.studentId),
            eq(assessments.semester, input.semester as any),
            eq(assessments.academicYear, input.academicYear)
          )
        )
        .orderBy(subjects.name);

      // Group by subject
      const subjectMap = new Map();
      for (const r of results) {
        const sid = r.subjects.id;
        if (!subjectMap.has(sid)) {
          subjectMap.set(sid, {
            subject: r.subjects,
            assessments: [],
          });
        }
        subjectMap.get(sid).assessments.push({
          gradeId: r.grades.id,
          assessmentName: r.assessments.name,
          type: r.assessments.type,
          marksObtained: r.grades.marksObtained,
          totalMarks: r.assessments.totalMarks,
          percentage: r.grades.percentage ? parseFloat(r.grades.percentage.toString()) : 0,
          grade: r.grades.grade,
          gpaPoints: r.grades.gpaPoints ? parseFloat(r.grades.gpaPoints.toString()) : 0,
          weight: r.assessments.weight ? parseFloat(r.assessments.weight.toString()) : 1,
        });
      }

      const subjectsData = Array.from(subjectMap.values()).map((s: any) => {
        const avgPercentage = s.assessments.reduce((sum: number, a: any) => sum + a.percentage, 0) / s.assessments.length;
        const avgGpa = s.assessments.reduce((sum: number, a: any) => sum + a.gpaPoints, 0) / s.assessments.length;
        return {
          ...s,
          avgPercentage: Math.round(avgPercentage * 10) / 10,
          avgGpa: Math.round(avgGpa * 100) / 100,
          overallGrade: calculateGradeLetter(avgPercentage),
        };
      });

      const overallGPA = subjectsData.length > 0
        ? subjectsData.reduce((sum: number, s: any) => sum + s.avgGpa, 0) / subjectsData.length
        : 0;

      return {
        student: {
          id: student[0].students.id,
          name: student[0].users.name,
          studentId: student[0].students.studentId,
          className: student[0].classes.name,
        },
        semester: input.semester,
        academicYear: input.academicYear,
        subjects: subjectsData,
        overallGPA: Math.round(overallGPA * 100) / 100,
      };
    }),
});
